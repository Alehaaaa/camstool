import maya.cmds as cmds, maya.mel as mel, os, json
from PySide2 import QtWidgets, QtCore, QtGui

from .settings import *
from .util import *


def get_camsDisplay_modeleditor():
    model_editor_cameras = {}
    panels = cmds.getPanel(type="modelPanel")
    for pl in panels:
        if cmds.modelEditor(pl, exists=True):
            cam = cmds.modelEditor(pl, q=True, camera=True)
            if cam:
                cam = cam.split("|")[-1]
                if cmds.objExists(cam + ".cams_display"):
                    model_editor_cameras[pl] = cam
    return model_editor_cameras


def get_preferences_display(cam):
    cam_attr = cam + ".cams_display"
    if cmds.objExists(cam_attr):
        attr_value = cmds.getAttr(cam_attr) or "{}"
        preferences = eval(attr_value)
    else:
        preferences = {}
        cmds.addAttr(cam, ln="cams_display", dt="string")
    return preferences


def get_cam_display(cam_panels, command, plugin=False):
    if plugin:
        var = eval(
            "cmds.modelEditor('"
            + cam_panels[-1]
            + "', q=1, queryPluginObjects='"
            + command
            + "')"
        )
    else:
        var = eval("cmds.modelEditor('" + cam_panels[-1] + "', q=1, " + command + "=1)")
    return var


def set_cam_display(cam_panels, command, plugin=False, switch=None):
    var = get_cam_display(cam_panels, command, plugin) if switch == None else not switch
    for i in cam_panels:
        e_cmd = (
            "pluginObjects=('{}', {})".format(command, not var)
            if plugin
            else "{}={}".format(command, not var)
        )
        try:
            eval("cmds.modelEditor('{}', e=1, {})".format(i, e_cmd))
        except:
            continue


def look_thru(cam, pane=None, ui=None):
    pane = pane or cmds.getPanel(wf=True)
    try:
        cmds.lookThru(pane, cam)
    except:
        if ui:
            ui.reload_cams_UI()
        return
    preferences = get_preferences_display(cam)
    if preferences:
        for command, plugin_switch in preferences.items():
            plugin, switch = (
                plugin_switch if type(plugin_switch) == tuple else (plugin_switch, 0)
            )
            set_cam_display([pane], command, plugin=plugin, switch=switch)


def get_model_from_pos(pos):
    widget = QtWidgets.QApplication.widgetAt(QtCore.QPoint(*pos))
    """Check if a given QWidget is a model editor in Maya."""
    if isinstance(widget, QtWidgets.QWidget):
        model_editor = widget.parent()
        if model_editor:
            return model_editor.objectName()
    return None


def get_pane_from_cam(cam):
    cam_panels = []
    current_cam = cam
    try:
        current_cam = cmds.listRelatives(current_cam)[0]
    except:
        pass
    for pane in cmds.getPanel(type="modelPanel"):
        pane_cam = cmds.modelPanel(pane, query=True, camera=True)
        if pane_cam:
            try:
                pane_cam = cmds.listRelatives(pane_cam)[0]
            except:
                pass
            if pane_cam == current_cam:
                cam_panels.append(pane)
    return cam_panels


def drag_insert_camera(camera, parent, pos):
    button_pos, cursor_pos = pos
    
    cursor_x, cursor_y =  cursor_pos.x(), cursor_pos.y()
    

    widget_name = get_model_from_pos((cursor_x, cursor_y))
    if widget_name and widget_name.startswith("modelPanel"):
        look_thru(camera, widget_name, parent)

    else:
        distance = QtGui.QVector2D(button_pos - cursor_pos).length()
        if distance < DPI(120):  # Adjust the threshold as needed
            return

        tear_window = tear_off_cam(camera)
        cmds.workspaceControl(tear_window, e=True, rsh=600, rsw=900)
        window_widget = omui.MQtUtil.findControl(tear_window)
        floating_window = wrapInstance(int(window_widget), QtWidgets.QWidget)

        # Get the parent widget of the floating window
        parent_widget = floating_window.parent().parent().parent().parent()

        # Set the initial position of the parent widget (floating window)
        parent_widget.move(cursor_x - parent_widget.geometry().width() / 2, cursor_y)


def select_cam(cam, button=None):
    if button:
        button.select_btn.setVisible(False)
        button.deselect_btn.setVisible(True)

    cmds.select(cam, add=True)


def deselect_cam(cam, button=None):
    if button:
        button.deselect_btn.setVisible(False)
        button.select_btn.setVisible(True)

    cmds.select(cam, deselect=True)


def duplicate_cam(cam, ui):
    cmds.undoInfo(openChunk=True)
    dup_cam = cmds.duplicate(cam)
    dup_cam = dup_cam[0]
    if cmds.listRelatives(dup_cam, parent=True):
        cmds.parent(dup_cam, w=1)
    cmds.showHidden(dup_cam)
    cmds.setAttr(cmds.listRelatives(dup_cam, shapes=True)[0] + ".renderable", False)

    type_attr = dup_cam + ".cams_type"
    if cmds.objExists(type_attr):
        cmds.deleteAttr(type_attr)

    cmds.undoInfo(closeChunk=True)

    ui.parentUI.reload_cams_UI()
    try:
        ui.context_menu.close()
    except:
        pass


def check_if_valid_camera(cam):
    if cmds.camera(cam, q=1, startupCamera=True):
        return "Default camera '" + cam + "' cannot be renamed."

    elif cmds.referenceQuery(cam, isNodeReferenced=True):
        return "Referenced camera '" + cam + "' cannot be renamed."


def rename_cam(cam, ui):
    check = check_if_valid_camera(cam)
    if check:
        cmds.warning(check)
        return

    re_win = QtWidgets.QInputDialog()
    re_win.setWindowTitle("Rename " + cam)
    re_win.setLabelText("New name:")
    re_win.setTextValue(cam)

    re_win.setWindowFlags(re_win.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)

    result = re_win.exec_()

    if result == QtWidgets.QDialog.Accepted:
        input = re_win.textValue()

        
        if cmds.objExists(cam + ".cams_type"):
            
            _parent = cmds.listRelatives(cam, parent=True)
            all_descendants = cmds.listRelatives(_parent, allDescendents=True) + _parent
            
            cmds.undoInfo(openChunk=True)

            name = cmds.rename(cam, input)
            for descendant in all_descendants:
                try:
                    cmds.rename(descendant, name + descendant[len(cam)::])
                except:
                    pass

            cmds.undoInfo(closeChunk=True)
        else:
            cmds.rename(cam, name)

        ui.reload_cams_UI()


def delete_cam(cam, ui):
    check = check_if_valid_camera(cam)
    if check:
        cmds.warning(check)
        return

    if cmds.objExists(cam):
        delete = QtWidgets.QMessageBox()
        response = delete.warning(
            None,
            "Delete " + cam,
            "Are you sure you want to delete " + cam + "?",
            delete.Yes | delete.No,
            delete.No,
        )

        if response == delete.Yes:
            if cmds.objExists(cam + ".cams_type"):
                try:
                    delete_target = cmds.listRelatives(cam, allParents=True)[0]
                except:
                    delete_target = cam

                if cmds.nodeType(delete_target) != "dagContainer":
                    try:
                        delete_target = cmds.listRelatives(
                            delete_target, allParents=True
                        )[0]
                    except:
                        pass
            else:
                delete_target = cam
            cmds.undoInfo(openChunk=True)
            cmds.delete(cam, inputConnectionsAndNodes=True)
            cmds.delete(delete_target, hierarchy="both")
            cmds.undoInfo(closeChunk=True)
    ui.reload_cams_UI()


def tear_off_cam(cam):
    tear_off_window = None
    for i in range(10):
        try:
            name = cam + "_WorkspaceControl" + (str(i) if i != 0 else "")
            tear_off_window = cmds.workspaceControl(name, label=cam, retain=False)
            break
        except:
            pass
    if tear_off_window == None:
        cmds.warning("Error making panel or too many Tear Off panels already made!")
        return

    cmds.paneLayout()
    new_pane = cmds.modelPanel()
    cmds.showWindow(tear_off_window)

    look_thru(cam, new_pane)
    cmds.modelEditor(new_pane, e=1, displayAppearance="smoothShaded")

    return tear_off_window


def close_UI(ui):
    if not ui:
        return
    
    def find():
        buttons = cmds.shelfLayout(currentShelf, q=True, ca=True)
        if buttons is None:
            return False
        else:
            for b in buttons:
                if (
                    cmds.shelfButton(b, exists=True)
                    and cmds.shelfButton(b, q=True, l=True) == tool
                ):
                    return True
        return False
    

    currentShelf = cmds.tabLayout(mel.eval("$nul=$gShelfTopLevel"), q=1, st=1)
    tool = ui.TITLE.lower()

    buttons = ["Yes", "Cancel"]
    messages = ["Closing Cams will NOT reopen it on Maya's next run.", "\nAre you sure you want to continue?"]

    if not find():
        buttons.insert(1, "Add to Shelf")
        messages.insert(1, "You will have to use a Shelf button or run Cams launch script.")
    

    box = cmds.confirmDialog(
        title="About to close Cams!",
        message="\n".join(messages),
        button=buttons,
        icon='information',
        defaultButton="Cancel",
        cancelButton="Cancel",
        dismissString="Cancel",
    )

    if box == "Add to Shelf":
        cmds.shelfButton(
            parent=currentShelf,
            i=os.path.join(
                os.environ["MAYA_APP_DIR"],
                cmds.about(v=True),
                "scripts",
                "aleha_tools",
                "_icons",
                tool + ".svg",
            ),
            label=tool,
            c="import aleha_tools.{} as {};{}.UI().showWindow()".format(
                tool, tool, tool
            ),
            annotation=tool.title() + " by Aleha",
        )
        ui.close()
    elif box == "Yes":
        ui.close()


# Open Tools
def run_tools(tool, cams_ui=None):
    if get_python_version() > 2:
        try:
            import importlib

            tool_module = importlib.import_module("aleha_tools._tools." + tool)
            importlib.reload(tool_module)
        except ImportError:
            cmds.error("Error importing module " + tool)
            return

        getattr(tool_module, tool)()

        if cams_ui:
            cams_ui.reload_cams_UI()

    else:
        cmds.warning("Work in Progress")


def get_release_notes_path(tool_folder = r"\\HKEY\temp\from_alejandro\cams_tool"):

    if os.path.exists(tool_folder):
        return os.path.join(tool_folder, "release_notes.json")


def get_latest_version():
    _release_notes = get_release_notes_path()

    if not os.path.exists(_release_notes):
        return
    else:
        with open(_release_notes, "r") as release:
            release_notes = json.load(release)

    try:
        changelog = release_notes.get("versions", "")
        blocked = release_notes.get("blocked", "")
        version = next(iter(changelog))
    except:
        return
    
    return version, changelog, blocked


# Check for Updates
def check_for_updates(ui, warning=True):

    tool_folder = r"\\HKEY\temp\from_alejandro\cams_tool"
    
    if os.path.exists(tool_folder):
        versions_folder = os.path.join(tool_folder, "versions")
        latest_file = [v for v in os.listdir(versions_folder)][-1]
        latest_file_path = os.path.join(versions_folder, latest_file)
    
    try:
        version, changelog, blocked = get_latest_version()
    except:
        if warning:
            make_inViewMessage(
                "<hl>No connection</hl>\nCould not sync with the server."
            )
        return
    
    if blocked and warning:
        make_inViewMessage(
            "<hl>Updates are blocked</hl>\nPlease wait until the problem is solved.", 'warning'
        )
        return

    notes_list = []
    for number, changes in changelog.items():
        version_changes = []
        version_changes.append(number)
        for line in changes:
            version_changes.append(" - " + line)
        notes_list.append(version_changes)

    notes_list = notes_list[:3]
    notes_list.append(["== And more =="])
    formated_changelog = "\n\n".join(["\n".join(x) for x in notes_list])

    if version > ui.VERSION:
        update_available = cmds.confirmDialog(
            title="New update for " + ui.TITLE + "!",
            message="Version {} available, you are using {}\n\nChangelog:\n{}".format(
                version, ui.VERSION, formated_changelog
            ),
            messageAlign="center",
            button=["Install", "Skip", "Close"],
            defaultButton="Install",
            cancelButton="Close",
        )
        if update_available == "Install":
            from . import updater

            try:
                from importlib import reload
            except:
                pass
            reload(updater)

            command = "import aleha_tools.cams as cams;cams.UI().showWindow()"
            # print(ui.TITLE.lower(), command, latest_file_path)
            updater.Updater().install(ui.TITLE.lower(), command, latest_file_path)
            cmds.evalDeferred(
                """
import aleha_tools."""
                + ui.TITLE.lower()
                + """ as cams
try:
    from importlib import reload
except ImportError:
    pass
reload(cams)
cams.UI().showWindow()
"""
            )
            make_inViewMessage(
                "Update finished successfully\ncurrent version is now <hl>"
                + version
                + "</hl></div>"
            )

        elif update_available == "Skip":
            ui.process_prefs(skip_update=True)

    elif warning:
        if version < ui.VERSION:
            make_inViewMessage(
                "You are using an unpublished\nversion <hl>"
                + ui.VERSION
                + "</hl></div>"
            )
        else:
            make_inViewMessage(
                "You are up-to-date.\nVersion <hl>" + ui.VERSION + "</hl></div>"
            )
