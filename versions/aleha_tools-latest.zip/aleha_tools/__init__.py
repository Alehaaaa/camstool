
DATA = {
    'TOOL': "cams",
    'VERSION': '0.2.02a',
    'AUTHOR': {
        'name': "Alehaaa",
        'website': "https://alehaaaa.github.io",
        'instagram': "https://www.instagram.com/alejandro_anim/",
    }
}
















