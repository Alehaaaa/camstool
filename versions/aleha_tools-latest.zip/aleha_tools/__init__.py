
DATA = {
    'TOOL': "cams",
    'VERSION': '0.2.02b',
    'AUTHOR': {
        'name': "Alehaaa",
        'website': "https://alehaaaa.github.io",
        'instagram': "https://www.instagram.com/alejandro_anim/",
    }
}

























