import maya.cmds as cmds, maya.mel as mel, os, json
try:
    from PySide2.QtWidgets import *
    from PySide2.QtCore import *
    from PySide2.QtGui import *
except ImportError:
    from PySide6.QtWidgets import *
    from PySide6.QtCore import *
    from PySide6.QtGui import *

from .settings import *
from .util import *




def install_userSetup(uninstall=False):
    userSetupFile = os.path.join(os.getenv('MAYA_APP_DIR'), "scripts", "userSetup.py")
    newUserSetup = ""
    startCode, endCode = "# start Cams", "# end Cams"

    try:
        with open(userSetupFile, 'r') as input_file:
            lines = input_file.readlines()

            # Remove existing block between startCode and endCode
            inside_block = False
            for line in lines:
                if line.strip() == startCode:
                    inside_block = True
                if not inside_block:
                    newUserSetup += line
                if line.strip() == endCode:
                    inside_block = False

            # Ensure there's always a two-line gap at the end
            newUserSetup = newUserSetup.rstrip() + "\n\n"

    except IOError:
        newUserSetup = ""

    CamsRunCode = startCode + "\n\nimport aleha_tools.cams as cams\ncmds.evalDeferred(\"cmds.evalDeferred('cams.show()',lowestPriority=True)\",lowestPriority=True)\n\n" + endCode

    if not uninstall: newUserSetup += CamsRunCode

    # Write the updated userSetup file
    with open(userSetupFile, 'w') as output_file:
        output_file.write(newUserSetup)


def unistall(ui):
    
    box = cmds.confirmDialog( title="About to Uninstall!",
                            message="Uninstalling Cams will remove ALL settings.\nAre you sure you want to continue?",
                            button=['Yes', 'Cancel'],
                            defaultButton='Cancel',
                            cancelButton='Cancel',
                            dismissString='Cancel' )

    if box == 'Yes':
        install_userSetup(uninstall=True)

        toolsFolder = os.path.join(os.environ["MAYA_APP_DIR"], "scripts", "aleha_tools")
        # Remove tool files
        if os.path.isdir(toolsFolder):
            for filename in os.listdir(toolsFolder):
                f = os.path.join(toolsFolder, filename)
                if ((ui.TOOL in f) or ("updater" in f)) and (f != "_pref"):
                    if os.path.isfile(f):
                        os.remove(f)
                    elif os.path.isdir(f):
                        shutil.rmtree(f)

        buttons = cmds.shelfLayout(cmds.tabLayout(mel.eval("$nul=$gShelfTopLevel"), q=1, st=1), q=True, ca=True)
        if buttons:
            for b in buttons:
                if cmds.shelfButton(b, exists=True) and cmds.shelfButton(b, q=True, l=True) == ui.TOOL:
                    cmds.deleteUI(b)
            global cams_aleha_tool
        if "cams_aleha_tool" in globals():
            try: close_all_Windows(cams_aleha_tool)
            except: pass
            del cams_aleha_tool



def get_camsDisplay_modeleditor():
    model_editor_cameras = {}
    panels = cmds.getPanel(type='modelPanel')
    for pl in panels:
        if cmds.modelEditor(pl, exists=True):
            cam = cmds.modelEditor(pl, q=True, camera=True)
            if cam:
                cam = cam.split('|')[-1]
                if cmds.objExists(cam +".cams_display"):
                    model_editor_cameras[pl] = cam
    return model_editor_cameras

def get_preferences_display(cam):
    cam_attr = cam +".cams_display"
    if cmds.objExists(cam_attr):
        attr_value = cmds.getAttr(cam_attr) or '{}'
        preferences = eval(attr_value)
    else:
        preferences = {}
        cmds.addAttr(cam, ln="cams_display", dt='string')
    return preferences


def get_cam_display(cam_panels, command, plugin=False):
    if plugin: return eval("cmds.modelEditor('"+ cam_panels[-1] +"', q=1, queryPluginObjects='"+ command +"')")
    else: return eval("cmds.modelEditor('"+ cam_panels[-1] +"', q=1, "+ command +"=1)")


def set_cam_display(cam_panels, command, plugin=False, switch=None):
    var = get_cam_display(cam_panels, command, plugin) if switch == None else not switch
    for i in cam_panels:
        e_cmd = "pluginObjects=('{}', {})".format(command, not var) if plugin else "{}={}".format(command, not var)
        try: eval("cmds.modelEditor('{}', e=1, {})".format(i, e_cmd))
        except: continue


def look_thru(cam, modelPane=None, ui=None):
    modelPane = modelPane or cmds.getPanel(wf=True)

    pane_widget = omui.MQtUtil.findControl(modelPane)
    if pane_widget:
        main_widget = get_maya_qt(pane_widget, QWidget).parent().parent().parent()
        if isinstance(main_widget, QWidget):
            try:cmds.workspaceControl(main_widget.objectName(), e=True, label=cam)
            except:pass

    try: cmds.lookThru(modelPane, cam)
    except:
        if ui: ui.reload_cams_UI()
        return
    preferences = get_preferences_display(cam)
    if preferences:
        for command, plugin_switch in preferences.items():
            plugin, switch = plugin_switch if type(plugin_switch) == tuple else (plugin_switch, 0)
            set_cam_display([modelPane], command, plugin=plugin, switch=switch)


def get_model_from_pos(pos):
    widget = QApplication.widgetAt(QPoint(*pos))
    """Check if a given QWidget is a model editor in Maya."""
    if isinstance(widget, QWidget):
        model_editor = widget.parent()
        if model_editor:
            return model_editor.objectName()
    return None


def get_panels_from_camera(cam):
    """Returns a set of model panels associated with a given camera transform or shape."""
    if cmds.objectType(cam, isType='transform'):
        cam_shape = cmds.listRelatives(cam, shapes=True)[0]
    else: cam_shape = cam

    return list({p for p in cmds.getPanel(type='modelPanel') if cmds.modelPanel(p, q=True, camera=True) in {cam, cam_shape}})


def drag_insert_camera(camera, parent, pos):
    button_pos, cursor_pos = pos
    
    cursor_x, cursor_y =  cursor_pos.x(), cursor_pos.y()
    

    widget_name = get_model_from_pos((cursor_x, cursor_y))
    if widget_name and widget_name.startswith("modelPanel"):
        look_thru(camera, widget_name, parent)

    else:
        distance = QVector2D(button_pos - cursor_pos).length()
        if distance < DPI(120):  # Adjust the threshold as needed
            return

        tear_window = tear_off_cam(camera)
        cmds.workspaceControl(tear_window, e=True, rsh=600, rsw=900)
        window_widget = omui.MQtUtil.findControl(tear_window)
        floating_window = wrapInstance(int(window_widget), QWidget)

        # Get the parent widget of the floating window
        main_parent_widget = floating_window.parent().parent().parent().parent()

        # Set the initial position of the parent widget (floating window)
        main_parent_widget.move(cursor_x - main_parent_widget.geometry().width() / 2, cursor_y)

        main_parent_widget.raise_()
        main_parent_widget.activateWindow()  # Activates the window to gain focus


def select_cam(cam, button = None):
    if button:
        button.select_action.setVisible(False)
        button.deselect_action.setVisible(True)

    cmds.select(cam, add=True)


def deselect_cam(cam, button = None):
    if button:
        button.deselect_action.setVisible(False)
        button.select_action.setVisible(True)

    cmds.select(cam, deselect=True)


def duplicate_cam(cam, ui):
    cmds.undoInfo(openChunk=True)
    dup_cam = cmds.duplicate(cam)
    dup_cam = dup_cam[0]
    if cmds.listRelatives(dup_cam, parent=True):
        cmds.parent(dup_cam, w=1)
    cmds.showHidden(dup_cam)
    cmds.setAttr(cmds.listRelatives(dup_cam, shapes=True)[0] + ".renderable", False)

    type_attr = dup_cam + ".cams_type"
    if cmds.objExists(type_attr):
        cmds.deleteAttr(type_attr)

    cmds.select(dup_cam)

    cmds.undoInfo(closeChunk=True)

    ui.parentUI.reload_cams_UI()
    try: ui.context_menu.close()
    except: pass


def check_if_valid_camera(cam, status = None):
    check = None
    if cmds.camera(cam, q=1, sc = True):
        check = True if status == None else "Default camera '" + cam + "' cannot be "+status+"."
    elif cmds.referenceQuery(cam, isNodeReferenced=True):
        check = True if status == None else "Referenced camera '" + cam + "' cannot be "+status+"."
    if check:
        if status: cmds.warning(check)
        return False
    return True


def rename_cam(cam, input=None, ui=None):
    if not check_if_valid_camera(cam,  status='renamed'): return

    if input == None:
        re_win = QInputDialog()
        re_win.setWindowTitle("Rename " + cam)
        re_win.setLabelText("New name:")
        re_win.setTextValue(cam)

        re_win.setWindowFlags(re_win.windowFlags() & ~Qt.WindowContextHelpButtonHint)

        result = re_win.exec_()

        if result == QDialog.Accepted:
            input = re_win.textValue()
        else: return

        
    if cmds.objExists(cam + ".cams_type"):
        
        _parent = cmds.listRelatives(cam, parent=True)
        all_descendants = cmds.listRelatives(_parent, allDescendents=True) + _parent
        
        cmds.undoInfo(openChunk=True)

        name = cmds.rename(cam, input)
        for descendant in all_descendants:
            try: cmds.rename(descendant, name + descendant[len(cam)::])
            except: pass

        cmds.undoInfo(closeChunk=True)
    else: name = cmds.rename(cam, input)

    if ui: ui.reload_cams_UI()
    return name




def delete_cam(cam, ui):
    if not check_if_valid_camera(cam, status='deleted'): return

    if cmds.objExists(cam):
        delete = QMessageBox()
        response = delete.warning(
            None,
            "Delete "+ cam,
            "Are you sure you want to delete "+ cam +"?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,  # Uso de StandardButton
            QMessageBox.StandardButton.No  # Botón por defecto
        )

        if response == QMessageBox.StandardButton.Yes:
            if cmds.objExists(cam +".cams_type"):
                try:
                    delete_target = cmds.listRelatives( cam, allParents=True )[0]
                except:
                    delete_target = cam

                if cmds.nodeType(delete_target) != "dagContainer":
                    try:
                        delete_target = cmds.listRelatives( delete_target, allParents=True )[0]
                    except:
                        pass
            else:
                delete_target = cam
            cmds.undoInfo(openChunk=True)
            cmds.delete(cam, inputConnectionsAndNodes=True)
            cmds.delete(delete_target, hierarchy="both")
            cmds.undoInfo(closeChunk=True)
    ui.reload_cams_UI()


def tear_off_cam(cam):
    tear_off_window = None
    for i in range (10):
        try:
            name = cam+'_WorkspaceControl'+(str(i) if i != 0 else '')
            tear_off_window = cmds.workspaceControl(name, label=cam, retain=False)
            break
        except:
            pass
    if tear_off_window == None:
        cmds.warning('Error making panel or too many Tear Off panels already made!')
        return
    
    cmds.paneLayout()
    new_pane = cmds.modelPanel()
    cmds.showWindow( tear_off_window )
    
    look_thru(cam, new_pane)
    cmds.modelEditor( new_pane, e=1, displayAppearance='smoothShaded' )

    cmds.workspaceControl(tear_off_window, e=1, rsh=600, rsw=900)
    return tear_off_window


def delete_maya_UI(ui = "CamsWorkspaceControl"):
    try:
        cmds.deleteUI(ui)
        cmds.workspaceControl(ui, e=True, close=True)
    except: pass
    

def close_all_Windows(ui):
    
    for window_ui in ["MultiCams", ui.workspace_control_name]:
        if cmds.workspaceControl(window_ui, exists=True):
            try: delete_maya_UI(window_ui)
            except: pass
    try:
        ui.kill_all_scriptJobs()
        ui.close()
        ui.deleteLater()
    except: pass



def close_UI(ui):
    if not ui: return
    elif ui.confirm_exit:
        currentShelf = cmds.tabLayout(mel.eval("$nul=$gShelfTopLevel"), q=1, st=1)
        tool = ui.TITLE.lower()

        def find():
            buttons = cmds.shelfLayout(currentShelf, q=True, ca=True)
            if buttons is None:
                return False
            else:
                for b in buttons:
                    if (
                        cmds.shelfButton(b, exists=True)
                        and cmds.shelfButton(b, q=True, l=True) == tool
                    ):
                        return True
            return False

        if not find():
            box = cmds.confirmDialog( title="About to close Cams!",
                                    message="Closing Cams will NOT reopen the UI on Maya's next launch.\nYou will have to use a Shelf button or run Cams launch script.\n\nAre you sure you want to continue?",
                                    button=['Yes', "Add to Shelf", 'Cancel'],
                                    defaultButton='Cancel',
                                    cancelButton='Cancel',
                                    dismissString='Cancel' )

            if box == 'Yes' or box == "Add to Shelf":
                if box == "Add to Shelf":
                    cmds.shelfButton(
                        parent=currentShelf,
                        i=os.path.join(
                            os.path.dirname(__file__),
                            "_icons",
                            tool +".svg",
                        ),
                        label=tool,
                        c="import aleha_tools.%s as %s;from importlib import reload;reload(%s);%s.show()" % (tool, tool, tool, tool),
                        annotation=tool.title() +" by Aleha",
                    )
            else: return
    close_all_Windows(ui)

# Open Tools
def run_tools(tool, ui=None):
    if get_python_version() > 2:
        try:
            import importlib
            tool_module = importlib.import_module("aleha_tools._tools."+ tool)
            importlib.reload(tool_module)
        except ImportError:
            cmds.error("Error importing module "+ tool)
            return

        if ui:
            tool_instance = getattr(tool_module, tool)()
            tool_instance.show_dialog(ui)
        else:
            getattr(tool_module, tool)()

    else: cmds.warning("Work in Progress")



def get_release_notes_path(tool_folder = r"\\HKEY\temp\from_alejandro\cams_tool"):

    if os.path.exists(tool_folder):
        return os.path.join(tool_folder, "release_notes.json")


def get_latest_version():
    _release_notes = get_release_notes_path()

    if not os.path.exists(_release_notes):
        return
    else:
        with open(_release_notes, "r") as release:
            release_notes = json.load(release)

    try:
        changelog = release_notes.get("versions", "")
        blocked = release_notes.get("blocked", "")
        version = next(iter(changelog))
    except: return
    
    return version, changelog, blocked


# Check for Updates
def check_for_updates(ui, warning=True):

    tool_folder = r"\\HKEY\temp\from_alejandro\cams_tool"

    if os.path.exists(tool_folder):
        versions_folder = os.path.join(tool_folder, "versions")
        latest_file = [v for v in os.listdir(versions_folder)][-1]
        latest_file_path = os.path.join(versions_folder, latest_file)
    
    try: version, changelog, blocked = get_latest_version()
    except:
        if warning: make_inViewMessage("<hl>No connection</hl>\nCould not sync with the server.")
        return
    
    if blocked:
        if warning:
            make_inViewMessage("<hl>Updates are blocked</hl>\nPlease wait until the problem is solved.", 'warning')
        return

    notes_list = []
    for number, changes in changelog.items():
        version_changes = []
        version_changes.append(number)
        for line in changes:
            version_changes.append(" - "+ line)
        notes_list.append(version_changes)
                
    notes_list = notes_list[:3]
    notes_list.append(["== And more =="])
    formated_changelog = "\n\n".join(["\n".join(x) for x in notes_list])

    if version > ui.VERSION:
        update_available = cmds.confirmDialog(
            title="New update for "+ ui.TITLE +"!",
            message="Version {} available, you are using {}\n\nChangelog:\n{}".format(version, ui.VERSION, formated_changelog),
            messageAlign="center",
            button=["Install", "Skip", "Close"],
            defaultButton="Install",
            cancelButton="Close",
        )
        if update_available == "Install":
            from . import updater
            try: from importlib import reload
            except: pass
            reload(updater)

            command = "import aleha_tools.cams as cams;try: from importlib import reload;reload(cams);cams.show()"
            updater.Updater().install(ui.TITLE.lower(), command, latest_file_path)
            cmds.evalDeferred(command)
            
            install_userSetup()
            make_inViewMessage("Update finished successfully\ncurrent version is now <hl>"+ version +"</hl></div>")

        elif update_available == "Skip":
            ui.process_prefs(skip_update=True)

    elif warning:
        if version < ui.VERSION: make_inViewMessage("You are using an unpublished\nversion <hl>"+ ui.VERSION+ "</hl></div>")
        else: make_inViewMessage("You are up-to-date.\nVersion <hl>" + ui.VERSION + "</hl></div>")

def check_author():
    import base64 as b
    return os.environ.get('USER', os.environ.get('USERNAME')) in [b.b64decode(x).decode() for x in [b"YWxlamFuZHJv", b'YWxlaGE=']]

def compile_version():
    if not check_author(): return
    module_path = r"\\HKEY\temp\from_alejandro\UpdateCompiler.py"
    if not os.path.isfile(module_path):
        cmds.error('Error: Module for Version Compiler not found.')

    import importlib
    spec = importlib.util.spec_from_file_location("compiler_cams", module_path)
    compile_cams_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(compile_cams_module)

    comp_cams_ins = compile_cams_module.CompileCams(os.path.dirname(__file__))
    comp_cams_ins.main()

def changes_compiler():
    if not check_author(): return
    module_path = r"\\HKEY\temp\from_alejandro\ChangesCompiler.py"
    if not os.path.isfile(module_path):
        cmds.error('Error: Module for Generate Changes not found.')

    import importlib
    spec = importlib.util.spec_from_file_location( "changes_cams", module_path)
    changes_cams_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(changes_cams_module)

    chan_cams_ins = changes_cams_module.CamsToolUpdater(os.path.dirname(__file__))
    changelog = chan_cams_ins.run()

    cmds.confirmDialog(m= '- ' + '\n- '.join(changelog))