import os, sys, maya.cmds as cmds
import maya.OpenMayaUI as omui

from PySide2 import QtWidgets
from shiboken2 import wrapInstance





def DPI(val):
    return omui.MQtUtil.dpiScale(val)


def return_icon_path(icon):
    script_directory = os.path.dirname(__file__)
    return os.path.join(script_directory, "_icons", icon)


def getcolor(camera):
    min_v = 100
    max_v = 170

    # Convert the UUID to a hexadecimal string
    hex_string = cmds.ls(camera, uuid=1)[0].split("-")

    # Extract RGB values from parts of the hexadecimal string
    r = int(hex_string[1], 16)
    g = int(hex_string[2], 16)
    b = int(hex_string[3], 16)

    max_range = max(r, g, b)
    default_color = []
    for i in [r, g, b]:
        i = int(min_v + (i / max_range) * (max_v - min_v))
        default_color.append(i)

    return default_color

def get_cameras(default = False):
    # Get all custom cameras in scene and the default ones
    non_startup_cameras = []
    startup_cameras = []
    
    for cam in cmds.ls(type=("camera")):
        kcam = cmds.listRelatives(cam, type="transform", p=True)[0]
        if not cmds.camera(kcam, q=1, startupCamera=True):
            non_startup_cameras.append(kcam)
        else:
            startup_cameras.append(kcam)
    return non_startup_cameras if not default else startup_cameras


def get_python_version():
    return sys.version_info.major


def get_maya_qt(ptr = omui.MQtUtil.mainWindow()):
    if get_python_version() < 3:
        main = wrapInstance(long(ptr), QtWidgets.QMainWindow)
    else:
        main = wrapInstance(int(ptr), QtWidgets.QMainWindow)
    return main


def delete_workspace_control(control):
    if cmds.workspaceControl(control, q=True, exists=True):
        cmds.workspaceControl(control, e=True, close=True)
        cmds.deleteUI(control, control=True)