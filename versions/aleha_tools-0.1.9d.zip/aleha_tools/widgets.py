from functools import partial
try:
    from PySide2.QtWidgets import *
    from PySide2.QtGui import *
    from PySide2.QtCore import *

except ImportError:
    from PySide6.QtWidgets import *
    from PySide6.QtGui import *
    from PySide6.QtCore import *
    
import maya.cmds as cmds
import base64

from .util import *
from .funcs import *





"""
QPainter for the cameras shelf tabBar
"""


class ShelfPainter(QWidget):
    def __init__(self, parent=None):
        super(ShelfPainter, self).__init__(parent)
        self.tabbar_width = DPI(16)
        self.line_thickness = DPI(1)
        self.line_color = QColor(130, 130, 130)
        self.margin = DPI(4)
        self.center = DPI(5)
        self.offset = DPI(1.5)

    def paintEvent(self, event):
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

        color = self.palette().color(self.backgroundRole())
        painter = QPainter(self)
        painter.setPen(QPen(color, self.tabbar_width))
        painter.drawLine(self.tabbar_width // 2, 0, self.tabbar_width // 2, self.height())
        
        pen = QPen(self.line_color)
        pen.setWidth(1)  # Line width of 1 pixel
        pen.setStyle(Qt.CustomDashLine)  # Enable custom dash pattern
        pen.setDashPattern([0.01, DPI(3)])  # 1 pixel dot, 1 pixel space
        painter.setPen(pen)

        painter.drawLine(
            QPointF(self.center - self.offset, self.margin / 3),
            QPointF(self.center - self.offset, self.height() - self.margin),
        )
        painter.drawLine(
            QPointF(self.center + self.offset, self.margin / 3),
            QPointF(self.center + self.offset, self.height() - self.margin),
        )

    def resizeEvent(self, event):
        self.update()

    def updateDrawingParameters(self, tabbar_width=None, line_thickness=None, line_color=None, margin=None, center=None, offset=None):
        """Update drawing parameters and refresh the widget."""
        if tabbar_width is not None: self.tabbar_width = tabbar_width.width()
        if line_thickness is not None: self.line_thickness = line_thickness
        if line_color is not None: self.line_color = line_color
        if margin is not None: self.margin = margin
        if center is not None: self.center = center
        if offset is not None: self.offset = offset
        self.update()


"""
QMenu that doesn't close
"""


class OpenMenu(QMenu):
    def __init__(self, title=None, parent=None):
        # If a title is provided, pass it to the QMenu constructor
        if title is not None: super(OpenMenu, self).__init__(title, parent)
        else: super(OpenMenu, self).__init__(parent)

        # Close this menu when the parent is destroyed
        if parent and hasattr(parent, "destroyed"):
            parent.destroyed.connect(self.close)

    def mouseReleaseEvent(self, e):
        action = self.activeAction()
        try:
            if isinstance(action, QWidgetAction):
                return
            elif action and action.isEnabled() and action.isCheckable():
                action.setEnabled(False)
                super(OpenMenu, self).mouseReleaseEvent(e)
                action.setEnabled(True)
                action.trigger()
            else:
                super(OpenMenu, self).mouseReleaseEvent(e)
        except Exception as ex:
            super(OpenMenu, self).mouseReleaseEvent(e)


"""
QPushButton hover detection
"""


class HoverButton(QPushButton):
    dropped = Signal(tuple)

    def __init__(self, camera, ui=None, width=True):
        super(HoverButton, self).__init__()
        self.parentUI = ui
        self.camera = camera
        self.width = width

        self.setAcceptDrops(True)
        
        cam_type = "camera"
        type_attr = camera +".cams_type"
        if cmds.objExists(type_attr):
            cam_type = cmds.getAttr(type_attr)
        
        self.setFixedHeight(DPI(25))
        self.changeName(camera)

        self.setToolTip(camera)
        self.setAttribute(Qt.WA_TranslucentBackground)

        base_color = getcolor(camera)
        self.base_color = ', '.join([str(x) for x in base_color])
        self.light_color = ', '.join([str(x * 1.2) for x in base_color])
        self.dark_color = ', '.join([str(x * 0.6) for x in base_color])

        self.set_default_style()
        self.setStatusTip("Look thru " + self.camera)
        
        self.default_icon = QIcon(return_icon_path(cam_type +".png"))

        self.select_icon = QIcon(return_icon_path("select.png"))
        self.deselect_icon = QIcon(return_icon_path("deselect.png"))
        self.duplicate_icon = QIcon(return_icon_path("duplicate.png"))
        self.rename_icon = QIcon(return_icon_path("rename.png"))

        self.remove_icon = QIcon(return_icon_path("remove.png"))
        self.tearoff_icon = QIcon(return_icon_path("tear_off.png"))
        self.attributes_icon = QIcon(return_icon_path("attributes.png"))

        self.setIcon(self.default_icon)


        # Right-click menu for button
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(
            lambda pos, c=self.camera, button=self, cam_type=cam_type: self.show_context_menu(
                pos, c, button, cam_type
            )
        )

        self.installEventFilter(self)
        self.dragging = False
        self.start_pos = None
        
        if self.parentUI:
            # Connect the signal to the slot
            try: self.parentUI.keys_pressed_changed.connect(self.onkeys_pressed_changed)
            except:pass

    def changeName(self, btn_name):
        if len(btn_name) > 10:
            btn_name = ".." + btn_name[-8:]
        if self.width: self.setFixedWidth(DPI(  25 + (len(btn_name) * 5.5)  ))
        self.setText(btn_name)


    def update_section_sub_elements(self, section, actions, cam_panels, cam, set=True):
        check = section.isChecked()
        # Handler function to update the check states of sub-elements based on the section's check state
        if set:
            commands = []
            for action, command, plugin in actions:
                action.setChecked(check)
                set_cam_display(cam_panels, command, plugin=plugin, switch=check)
                commands.append((command, plugin, check))
            self.save_display_to_cam(cam)

    def set_display_attribute(self, cam, action, cam_panels, s_action, actions, command, plugin=False):
        s_action.setChecked(not any(not a[0].isChecked() for a in actions))
        if cam_panels:
            set_cam_display(cam_panels, command, plugin=plugin)
        self.save_display_to_cam(cam, [(command, plugin, action.isChecked())])

    def save_display_to_cam(self, cam, commands = None):
        all_preferences=[(p[1], p[2]) for s in self.show_elements.values() for p in s]
        current_preferences = get_preferences_display(cam)

        if not current_preferences:
            cam_panels = self.get_pane_from_cam(cam)
            for preference in all_preferences:
                pref, plugin = preference
                value = get_cam_display(cam_panels, pref, plugin=plugin)
                current_preferences[pref] = (plugin, value)
        if commands:
            if not isinstance(commands, list):
                commands = [commands]
            for command in commands:
                command, plugin, value = command
                current_preferences[command] = (plugin, value)

        cmds.setAttr(cam +".cams_display", current_preferences, type='string')

    def get_pane_from_cam(self, cam):
        cam_panels = []
        current_cam = cam
        try:current_cam = cmds.listRelatives(current_cam)[0]
        except:pass
        for pane in cmds.getPanel(type="modelPanel"):
            pane_cam = cmds.modelPanel(pane, query=True, camera=True)
            if pane_cam:
                try:pane_cam = cmds.listRelatives(pane_cam)[0]
                except:pass
                if pane_cam == current_cam:
                    cam_panels.append(pane)
        return cam_panels



    def enter_edit_mode(self, cam):
        self.context_menu_lineedit.setText(cam)
        self.context_menu_lineedit.setFixedSize(self.context_menu_label.width(), DPI(32))

        self.context_menu.removeAction(self.context_menu_label_action)
        self.context_menu.insertAction(self.context_menu.actions()[0], self.context_menu_lineedit_action)

        self.context_menu_lineedit.setFocus()

    def context_menu_rename_cam(self, cam):
        new_name = self.context_menu_lineedit.text()
        if new_name and new_name != cam:
            new_name = rename_cam(cam, new_name, self.parentUI)
            if new_name: self.context_menu_label.setText('...' + new_name[-17:] if len(new_name) > 18 else new_name)

        self.context_menu.removeAction(self.context_menu_lineedit_action)
        self.context_menu.insertAction(self.context_menu.actions()[1], self.context_menu_label_action)

    def show_context_menu(self, pos, cam, button, cam_type="camera"):
        if not cmds.objExists(cam):
            self.parentUI.reload_cams_UI()
            return

        self.context_menu = OpenMenu()

        self.context_menu_lineedit = QLineEdit()
        self.context_menu_lineedit.setContentsMargins(DPI(20), 0, DPI(20), 0)
        self.context_menu_lineedit.setStyleSheet("font-size: " + str(DPI(14)) + "px; font-weight: bold;")
        self.context_menu_lineedit.selectAll()
        self.context_menu_lineedit.returnPressed.connect(lambda: self.context_menu_rename_cam(cam))

        self.context_menu_lineedit_action = QWidgetAction(self)
        self.context_menu_lineedit_action.setDefaultWidget(self.context_menu_lineedit)

        self.context_menu_label = QLabel('...' + cam[-17:] if len(cam) > 18 else cam)
        self.context_menu_label.setFixedHeight(DPI(32))
        self.context_menu_label.setContentsMargins(DPI(20), 0, DPI(20), 0)
        self.context_menu_label.setStyleSheet("font-size: " + str(DPI(14)) + "px; font-weight: bold;")

        self.context_menu_label_action = QWidgetAction(self)
        self.context_menu_label_action.setDefaultWidget(self.context_menu_label)

        if check_if_valid_camera(cam):
            self.context_menu_label.setCursor(Qt.IBeamCursor)
            self.context_menu_label.mouseDoubleClickEvent = lambda event: self.enter_edit_mode(cam)

        self.context_menu.addAction(self.context_menu_label_action)



        self.select_btn = self.context_menu.addAction(
            QIcon(return_icon_path("select.png")),
            "Select",
            partial(select_cam, cam, self),
        )
        self.deselect_btn = self.context_menu.addAction(
            QIcon(return_icon_path("deselect.png")),
            "Deselect",
            partial(deselect_cam, cam, self),
        )
        
        if cam in cmds.ls(selection=True):
            self.select_btn.setVisible(False)
        else:
            self.deselect_btn.setVisible(False)


        self.context_menu.addAction(
            QIcon(return_icon_path("duplicate.png")),
            "Duplicate",
            partial(duplicate_cam, cam, self),
        )
        if cam == self.parentUI.default_cam[0]:
            default_cam_menu = OpenMenu("Main Camera")
            default_cam_menu.setIcon(QIcon(return_icon_path("camera.png")))
            default_cam_menu_grp = QActionGroup(self)
            
            for c in get_cameras(default=True):
                action = default_cam_menu.addAction(c, partial(self.set_default_cam, (c, True)))
                default_cam_menu_grp.addAction(action)
                action.setCheckable(True)
                action.setChecked(c == cam)
            self.context_menu.addMenu(default_cam_menu)

        if cam != self.parentUI.default_cam[0] and not cmds.referenceQuery( cam, isNodeReferenced=True ):
            self.context_menu.addAction(
                QIcon(return_icon_path("rename.png")),
                "Rename",
                partial(rename_cam, cam, self.parentUI),
            )

        self.context_menu.addSeparator()

        self.menu_show = OpenMenu("Viewport Show")
        self.menu_show.setTearOffEnabled(True)
        cam_panels = self.get_pane_from_cam(cam)
        visible_planels = bool(cam_panels)

        # Mark the ones that are plugins
        self.show_elements = {
            "Curves": (
                ("NURBS Curves", "nurbsCurves", 0),
                ("NURBS Surfaces", "nurbsSurfaces", 0),
            ),
            "Surfaces": (
                ("Polygons", "polymeshes", 0),
                ("Textures", "displayTextures", 0),
            ),
            "Visualising": (
                ("Cameras", "cameras", 0),
                ("Hold-Outs", "holdOuts", 0),
                ("Image Planes", "imagePlane", 0),
                ("Motion Trails", "motionTrails", 0),
            ),
            "Rigging": (
                ("Locators", "locators", 0),
                ("IK Handles", "ikHandles", 0),
                ("Joints", "joints", 0),
                ("Deformers", "deformers", 0),
            ),
            "Viewport Utilities": (
                ("Grid", "grid", 0),
                ("Manipulators", "manipulators", 0),
                ("Selection Highlight", "selectionHiliteDisplay", 0),
            ),
            "Plugins": (
                ("GPU Cache", "gpuCacheDisplayFilter", 1),
                ("Blue Pencil", "bluePencil", 0),
            ),
        }
        preferences = get_preferences_display(cam)

        for section in list(self.show_elements.keys()):
            self.menu_show.addSeparator()
            s_action = self.menu_show.addAction(section)
            s_action.setCheckable(True)

            actions = []
            for el in self.show_elements[section]:
                pretty, command, plugin = el

                el_action = self.menu_show.addAction("     "+ pretty)
                el_action.setCheckable(True)
                actions.append((el_action, command, plugin))

            for action, command, plugin in actions:
                action.triggered.connect(partial(self.set_display_attribute, cam, action, cam_panels, s_action, actions, command, plugin=plugin))
                if visible_planels:
                    action.setChecked(get_cam_display(cam_panels, command, plugin=plugin))

                elif preferences:
                    action.setChecked(preferences.get(command, ['', 0])[1])
                        

            s_action.setChecked(all(e.isChecked() for e in [a[0] for a in actions]))
            s_action.triggered.connect(partial(self.update_section_sub_elements, s_action, actions, cam_panels, cam))

        self.context_menu.addMenu(self.menu_show)    


        if cam_type == "camera_aim":
            offset_attr = cam +".cams_aim_offset"
            if cmds.objExists(offset_attr):
                self.context_menu.addAction(
                    QIcon(return_icon_path("aim.png")), "Position Aim", partial(self.position_aim_offset, offset_attr)
                )

        elif cam_type == "camera_follow":
            const_attr = cam +'.cams_follow_attr'
            if cmds.objExists(const_attr):
                
                const_switch_attr = cmds.getAttr(const_attr)
                const_switch = cmds.getAttr(const_switch_attr)

                follow_consts_menu = OpenMenu("Follow Mode")
                follow_consts_action_grp = QActionGroup(self)
                follow_consts_menu.setIcon(QIcon(return_icon_path("follow.png")))
                
                
                self.parent_const_btn = follow_consts_menu.addAction("Position, Rotation")
                follow_consts_action_grp.addAction(self.parent_const_btn)
                self.parent_const_btn.setCheckable(True)
                self.parent_const_btn.setChecked(const_switch)

                self.point_const_btn = follow_consts_menu.addAction("Only Position")
                follow_consts_action_grp.addAction(self.point_const_btn)
                self.point_const_btn.setCheckable(True)
                self.point_const_btn.setChecked(not const_switch)

                self.point_const_btn.triggered.connect(partial(cmds.setAttr, const_switch_attr, False))
                self.parent_const_btn.triggered.connect(partial(cmds.setAttr, const_switch_attr, True))

                self.context_menu.addMenu(follow_consts_menu)
        
        self.context_menu.addSeparator()


        self.resolution_checkbox = self.context_menu.addAction(
            "Display Gate", partial(self.resolution_cam, cam)
        )
        self.resolution_checkbox.setCheckable(True)
        self.resolution_checkbox.setChecked(
            cmds.getAttr(cam +".displayResolution")
        )

        self.context_menu.addAction(
            QIcon(return_icon_path("attributes.png")),
            "Attributes",
            partial(Attributes.show_dialog, cam, self.window()),
        )

        self.context_menu.addAction(QIcon(return_icon_path("default.png")), "Apply Defaults", partial(self.parentUI.apply_camera_default, cam, self))
        self.context_menu.addSeparator()

        self.context_menu.addAction(
            QIcon(return_icon_path("tear_off.png")),
            "Tear Off Copy",
            partial(tear_off_cam, cam),
        )

        if cam != self.parentUI.default_cam[0] and not cmds.referenceQuery( cam, isNodeReferenced=True ):
            self.context_menu.addSeparator()
            self.context_menu.addAction(
                QIcon(return_icon_path("remove.png")),
                "Delete",
                partial(delete_cam, cam, self.parentUI),
            )

        self.context_menu.exec_(button.mapToGlobal(pos))

    def position_aim_offset(self, cam, offset_attr):
        try:
            type, uuid = eval(cmds.getAttr(offset_attr))
            aim_offset = cmds.ls(uuid, type=type)
            cmds.select(cmds.ls(uuid, type=type), replace=True)
        except:
            try:
                attr_value = cmds.getAttr(offset_attr)
                if attr_value.count('|') and attr_value.startswith('|'):
                    attr_value = attr_value[1:]
                aim_offset = cmds.ls((attr_value), long=True)
                if len(aim_offset) > 1:
                    for o in aim_offset:
                        _parent = cmds.listRelatives(o, allParents=True, fullPath=True)
                        if _parent:
                            if '|' in _parent[0]:
                                main_parent = [p for p in _parent[0].split('|') if p][0]
                                if cam in cmds.listRelatives(main_parent, children=True):
                                    aim_offset = o
                                    offset_reference = f"['{cmds.objectType(o)}', '{cmds.ls(o, uuid=True)[0]}']"
                                    cmds.setAttr(offset_attr, offset_reference, type="string")
                                    break
            except:
                try:
                    for child in cmds.listRelatives(cmds.listRelatives(cam, parent=True), allDescendents=True, fullPath=True):
                        if cmds.objectType(child) == 'locator':
                            aim_offset = child
                except:pass

        if not aim_offset:
            cmds.error('Could not select the Aim Locator for: %s' % cam)
            self.context_menu.close()
            return

        cmds.select(aim_offset, replace=True)
        cmds.setToolTo("moveSuperContext")
        self.context_menu.close()
    
    def resolution_cam(self, cam):
        cmds.setAttr(cam +".displayGateMask", self.resolution_checkbox.isChecked())
        cmds.setAttr(cam +".displayResolution", self.resolution_checkbox.isChecked())
    
    def set_default_cam(self, cam):
        self.parentUI.process_prefs(cam=cam)
        self.context_menu.close()

    def onkeys_pressed_changed(self):
        self.parent_pressed_keys = self.parentUI.keys_pressed
        if self.underMouse():
            control_pressed, shift_pressed, alt_pressed = self.parent_pressed_keys.values()
            try:
                self.clicked.disconnect()
            except:pass

            if shift_pressed and not control_pressed and not alt_pressed:
                self.setIcon(self.select_icon)
                self.clicked.connect(partial(select_cam, self.camera))
                self.setStatusTip("Add " + self.camera + " to selection")

            elif control_pressed and not shift_pressed and not alt_pressed:
                self.setIcon(self.deselect_icon)
                self.clicked.connect(partial(deselect_cam, self.camera))
                self.setStatusTip("Remove " + self.camera + " from selection")

            elif control_pressed and shift_pressed and not alt_pressed:
                self.setIcon(self.duplicate_icon)
                self.clicked.connect(partial(duplicate_cam, self.camera, self))
                self.setStatusTip("Duplicate " + self.camera)

            elif control_pressed and alt_pressed and not shift_pressed:
                self.setIcon(self.rename_icon)
                self.clicked.connect(partial(rename_cam, self.camera, self.parentUI))
                self.setStatusTip("Rename " + self.camera)

            elif control_pressed and alt_pressed and shift_pressed:
                self.setIcon(self.remove_icon)
                self.clicked.connect(partial(delete_cam, self.camera, self.parentUI))
                self.setStatusTip("Delete " + self.camera)

            elif alt_pressed and shift_pressed and not control_pressed:
                self.setIcon(self.tearoff_icon)
                self.clicked.connect(partial(tear_off_cam, self.camera))
                self.setStatusTip("Tear Off " + self.camera)

            elif alt_pressed and not control_pressed and not shift_pressed:
                self.setIcon(self.attributes_icon)
                self.clicked.connect(partial(Attributes.show_dialog, self.camera, self.window()))
                self.setStatusTip("Attributes of " + self.camera)

            else:
                self.setIcon(self.default_icon)
                self.clicked.connect(partial(look_thru, cam=self.camera, ui=self.parentUI))
                self.setStatusTip("Look thru " + self.camera)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.start_pos = e.pos()
            self.setStyleSheet(self.styleSheet() + f"""
                QPushButton:pressed {{
                    background-color: rgb({self.dark_color});
                }}
            """)
        super(HoverButton, self).mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if not self.start_pos or (e.pos() - self.start_pos).manhattanLength() < QApplication.startDragDistance():
            return

        # Start drag operation
        drag = QDrag(self)
        mime_data = QMimeData()
        mime_data.setData("application/maya-data", b"")
        drag.setMimeData(mime_data)

        # Set the pixmap
        pixmap = self.grab()
        drag.setPixmap(pixmap)
        # shift the Pixmap so that it coincides with the cursor position
        drag.setHotSpot(self.start_pos)

        # Execute the drag operation
        drag.exec_(Qt.MoveAction)

        button_pos = QPoint(e.globalPos().x() - self.sizeHint().width() / 2, e.globalPos().y() - self.sizeHint().height() / 2)
        cursor_pos = QCursor.pos()

        self.dropped.emit((button_pos, cursor_pos))

        self.set_default_style()

    def set_default_style(self):
        self.setStyleSheet(self.styleSheet() + f"""
            QPushButton {{
                padding-left: {DPI(4)}px;
                padding-right: {DPI(4)}px;
                color: black;
                background-color: rgb({self.base_color});
                border-radius: {DPI(5)}px;
            }}
            QPushButton:hover {{
                background-color: rgb({self.light_color});
            }}

            QToolTip {{ 
                background-color: rgb({self.light_color});
            }}
        """)

    def mouseReleaseEvent(self, e):
        self.start_pos = None
        super(HoverButton, self).mouseReleaseEvent(e)


    def eventFilter(self, obj, event):
        if event.type() == QEvent.Enter:
            self.onkeys_pressed_changed()

        if event.type() == QEvent.Leave:
            self.set_default_style()

            self.setIcon(self.default_icon)
            self.setDown(False)

        if get_python_version() == 2: return super(HoverButton, self).eventFilter(obj, event)
        elif get_python_version() == 3: return super().eventFilter(obj, event)



"""
QScroll for the cameras layout
"""


class HorizontalScrollArea(QScrollArea):
    def __init__(self, height, parent=None):
        super(HorizontalScrollArea, self).__init__(parent)

        self.setFrameStyle(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setWidgetResizable(True)
        self.setFixedHeight(height)

        # Create a container widget for the content
        self.container_widget = QWidget(self)
        self.container_layout = QHBoxLayout(self.container_widget)
        self.container_layout.setContentsMargins(0, 0, 0, 0)
        self.container_layout.setSpacing(DPI(5))

        # Set the container widget as the scroll area's widget
        self.setWidget(self.container_widget)

    def wheelEvent(self, event):
        if event.type() == QWheelEvent.Wheel:
            delta = event.angleDelta().y() / 120  # Normalizing delta
            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - (delta * 30)
            )
            event.accept()
        super(HorizontalScrollArea, self).wheelEvent(event)


"""
Attributes
"""


class Attributes(QDialog):
    dlg_instance = None

    @classmethod
    def show_dialog(cls, cams, parent):
        try:
            cls.dlg_instance.close()
            cls.dlg_instance.deleteLater()
        except:
            pass

        cls.dlg_instance = Attributes(cams, parent)
        cls.dlg_instance.show()

    def __init__(self, cam, parent=None):
        super(Attributes, self).__init__(parent)

        self.cam = cam

        self.setWindowTitle("Attributes: "+ self.cam)
        self.setWindowFlags(self.windowFlags() | Qt.WindowCloseButtonHint)

        # First section: Attributes
        self.onlyFloat = QDoubleValidator(self)

        self.create_layouts()
        self.create_widgets()
        self.create_connections()
        
        self.setFixedSize(self.sizeHint().width(), self.sizeHint().height())



    def create_layouts(self):
        self.form_layout = QFormLayout(self)
        self.form_layout.setVerticalSpacing(DPI(10))
        self.focal_length_container = QHBoxLayout()
        self.near_clip_plane_container = QHBoxLayout()
        self.far_clip_plane_container = QHBoxLayout()
        self.overscan_container = QHBoxLayout()
        self.opacity_container = QHBoxLayout()
        self.color_slider_and_picker = QHBoxLayout()
        self.apply_buttons = QHBoxLayout()

    def create_widgets(self):
        self.focal_length_slider = QSlider(Qt.Horizontal)
        self.focal_length_slider.setRange(2500, 500000)
        self.focal_length_slider.setValue(
            int(round(cmds.getAttr(self.cam +".fl") * 1000))
        )

        self.focal_length_value = QLineEdit()
        self.focal_length_value.setText(
            str(self.get_float(self.focal_length_slider.value()))
        )
        self.focal_length_value.setFixedWidth(DPI(80))

        self.overscan_slider = QSlider(Qt.Horizontal)
        self.overscan_slider.setRange(1000, 2000)
        self.overscan_slider.setValue(
            int(cmds.getAttr(self.cam +".overscan") * 1000)
        )

        self.overscan_value = QLineEdit()
        self.overscan_value.setText(str(self.get_float(self.overscan_slider.value())))
        self.overscan_value.setFixedWidth(DPI(80))

        self.near_clip_plane = QLineEdit()
        self.far_clip_plane = QLineEdit()
        self.near_clip_plane.setFixedWidth(DPI(80))
        self.far_clip_plane.setFixedWidth(DPI(80))

        self.focal_length_value.setValidator(self.onlyFloat)
        self.overscan_value.setValidator(self.onlyFloat)
        self.near_clip_plane.setValidator(self.onlyFloat)
        self.far_clip_plane.setValidator(self.onlyFloat)

        self.near_clip_plane.setText(str(cmds.getAttr(self.cam +".ncp")))
        self.far_clip_plane.setText(str(cmds.getAttr(self.cam +".fcp")))
        
        self.near_clip_lock = self.create_lock_button()
        self.near_clip_lock.setVisible(False)
        self.near_clip_plane_container.addWidget(self.near_clip_plane)
        self.near_clip_plane_container.addStretch()
        self.near_clip_plane_container.addWidget(self.near_clip_lock)

        self.far_clip_lock = self.create_lock_button()
        self.far_clip_lock.setVisible(False)
        self.far_clip_plane_container.addWidget(self.far_clip_plane)
        self.far_clip_plane_container.addStretch()
        self.far_clip_plane_container.addWidget(self.far_clip_lock)

        self.focal_length_lock = self.create_lock_button()
        self.focal_length_lock.setVisible(False)
        self.focal_length_container.addWidget(self.focal_length_value)
        self.focal_length_container.addWidget(self.focal_length_slider)
        self.focal_length_container.addStretch()
        self.focal_length_container.addWidget(self.focal_length_lock)

        self.overscan_lock = self.create_lock_button()
        self.overscan_lock.setVisible(False)
        self.overscan_container.addWidget(self.overscan_value)
        self.overscan_container.addWidget(self.overscan_slider)
        self.overscan_container.addStretch()
        self.overscan_container.addWidget(self.overscan_lock)

        # Second section: Display Attributes
        self.gate_mask_opacity_slider = QSlider(Qt.Horizontal)
        self.gate_mask_opacity_slider.setRange(0, 1000)
        self.gate_mask_opacity_slider.setValue(
            int(
                round(cmds.getAttr(self.cam +".displayGateMaskOpacity") * 1000)
            )
        )
        self.gate_mask_opacity_value = QLineEdit()
        self.gate_mask_opacity_value.setText(
            str(self.get_float(self.gate_mask_opacity_slider.value()))
        )
        self.gate_mask_opacity_value.setFixedWidth(DPI(80))
        
        self.opacity_lock = self.create_lock_button()
        self.opacity_lock.setVisible(False)
        self.opacity_container.addWidget(self.gate_mask_opacity_value)
        self.opacity_container.addWidget(self.gate_mask_opacity_slider)
        self.opacity_container.addStretch()
        self.opacity_container.addWidget(self.opacity_lock)

        self.gate_mask_color_slider = QSlider(Qt.Horizontal)
        self.gate_mask_color_slider.setRange(0, 255)
        self.gate_mask_color_slider.setValue(128)
        self.gate_mask_color_picker = QPushButton()
        self.gate_mask_color_picker.setFixedWidth(DPI(80))
        self.gate_mask_color_picker.setFixedHeight(DPI(17))

        self.update_button_color(self.cam)

        self.color_lock = self.create_lock_button()
        self.color_lock.setVisible(False)
        self.color_slider_and_picker.addWidget(self.gate_mask_color_picker)
        self.color_slider_and_picker.addWidget(self.gate_mask_color_slider)
        self.color_slider_and_picker.addStretch()
        self.color_slider_and_picker.addWidget(self.color_lock)

        self.ok_btn = QPushButton("OK")
        self.apply_btn = QPushButton("Apply")
        self.cancel_btn = QPushButton("Cancel")

        self.apply_buttons.addWidget(self.ok_btn)
        self.apply_buttons.addWidget(self.apply_btn)
        self.apply_buttons.addWidget(self.cancel_btn)

        self.form_layout.addRow("Focal Length:", self.focal_length_container)
        self.form_layout.addRow(QFrame(frameShape=QFrame.HLine))
        self.form_layout.addRow("Near Clip Plane:", self.near_clip_plane_container)
        self.form_layout.addRow("Far Clip Plane:", self.far_clip_plane_container)
        self.form_layout.addRow(QFrame(frameShape=QFrame.HLine))
        self.form_layout.addRow("Overscan:", self.overscan_container)
        self.form_layout.addRow("Gate Mask Opacity:", self.opacity_container)
        self.form_layout.addRow("Gate Mask Color:", self.color_slider_and_picker)

        self.form_layout.addRow(self.apply_buttons)

        
        self.all_widgets = [
            {"target" : [self.focal_length_value, self.focal_length_slider], "attr" : ".fl", "lock" : self.focal_length_lock},
            {"target" : [self.overscan_value, self.overscan_slider], "attr" : ".overscan", "lock" : self.overscan_lock},
            {"target" : [self.near_clip_plane], "attr" : ".ncp", "lock" : self.near_clip_lock},
            {"target" : [self.far_clip_plane], "attr" : ".fcp", "lock" : self.far_clip_lock},
            {"target" : [self.gate_mask_opacity_value, self.gate_mask_color_slider], "attr" : ".displayGateMaskOpacity", "lock" : self.opacity_lock},
            {"target" : [self.gate_mask_color_picker, self.gate_mask_opacity_slider], "attr" : ".displayGateMaskColor", "lock" : self.color_lock},
        ]

    def create_connections(self):


        for widget in self.all_widgets:
            attr = self.cam + widget.get("attr", "")
            targets = widget.get("target", [])
            lock_btn = widget.get("lock", "")

            settable = True

            if not cmds.getAttr(attr, settable=True):
                settable = False
                lock_btn.setVisible(True)
                lock_btn.clicked.connect(partial(self.disconnect_locked_attr, attr, targets, lock_btn))

            for target in targets:
                value = cmds.getAttr(attr)
                if isinstance(target, QLineEdit):
                    target.setText(str(str(self.get_float(value * 1000))))
                    target.returnPressed.connect(
                        partial(self.apply_modifications, self.cam, close=True)
                    )
                elif isinstance(target, QSlider) and type(value) != list:
                    target.setValue(int(round(value * 1000)))

                target.setEnabled(settable)
                    
                    


        self.ok_btn.clicked.connect(
            partial(self.apply_modifications, self.cam, close=True)
        )
        self.apply_btn.clicked.connect(partial(self.apply_modifications, self.cam))
        self.cancel_btn.clicked.connect(self.close)

        self.focal_length_slider.valueChanged.connect(
            lambda: self.focal_length_value.setText(
                str(self.get_float(self.focal_length_slider.value()))
            )
        )

        self.overscan_slider.valueChanged.connect(
            lambda: self.overscan_value.setText(
                str(self.get_float(self.overscan_slider.value()))
            )
        )

        self.gate_mask_opacity_slider.valueChanged.connect(
            lambda: self.gate_mask_opacity_value.setText(
                self.get_float(self.gate_mask_opacity_slider.value())
            )
        )

        self.gate_mask_color_picker.clicked.connect(
            lambda: self.show_color_selector(self.gate_mask_color_picker)
        )

        self.gate_mask_color_slider.valueChanged.connect(
            lambda: self.update_button_value(self.gate_mask_color_slider.value())
        )


    def create_lock_button(self):
        lock_btn = QPushButton()
        lock_btn.setToolTip("Break connection")
        lock_btn.setStatusTip("Break connection")

        lock_btn.setIcon(QIcon(return_icon_path("locked.png")))
        lock_btn.setFixedSize(DPI(15), DPI(15))

        return lock_btn
    
    def disconnect_locked_attr(self, attr, targets, lock_btn):
        res = QMessageBox.question(None,
            "Break connection",
            "Are you sure you want to break the connection to\n'"+ attr +"'?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No)
        if res != QMessageBox.Yes:
            return
        connections = cmds.listConnections(attr, plugs=True)
        if connections:
            cmds.disconnectAttr(connections[0], attr)

        for target in targets:
            target.setEnabled(True)
        
        lock_btn.setVisible(False)

    """
    Create functions
    """

    def apply_modifications(self, cam, close=False):
        cmds.undoInfo(chunkName="applyCamAttributes", openChunk=True)
        try:
            self.get_picker_color()
            parameters = {
                "fl": self.focal_length_value.text(),
                "overscan": self.overscan_value.text(),
                "ncp": self.near_clip_plane.text(),
                "fcp": self.far_clip_plane.text(),
                "displayGateMaskOpacity": self.gate_mask_opacity_value.text(),
                "displayGateMaskColor": self.gate_mask_color_rgbf,
            }

            for i, v in parameters.items():
                attr = cam +"."+ i
                if cmds.getAttr(attr, settable=True):
                    if v:
                        if type(v) != list:
                            cmds.setAttr(attr, float(v))
                        else:
                            r, g, b = v
                            cmds.setAttr(attr, r, g, b, type="double3")

            if close:
                self.close()
        finally:
            cmds.undoInfo(closeChunk=True)

    def get_float(self, value):
        return "%.3f" % (value / 1000.0)

    def get_picker_color(self):
        style_sheet = self.gate_mask_color_picker.styleSheet()
        bg_color = style_sheet[style_sheet.find(":") + 1 :].strip()
        qcolor = QColor(bg_color)
        r, g, b, _ = qcolor.getRgbF()
        self.gate_mask_color_rgbf = [r, g, b]

    def update_button_color(self, cam):
        rgb = cmds.getAttr(cam + ".displayGateMaskColor")[0]
        qcolor = QColor(*[int(q * 255) for q in rgb])
        h, s, v, _ = qcolor.getHsv()
        qcolor.setHsv(h, s, v)
        self.gate_mask_color_picker.setStyleSheet(
            "background-color: "+ qcolor.name()
        )
        self.gate_mask_color_slider.setValue(v)

    def update_button_value(self, value):
        color = self.gate_mask_color_picker.palette().color(QPalette.Button)
        h, s, v, _ = color.getHsv()
        color.setHsv(h, s, value)
        self.gate_mask_color_picker.setStyleSheet(
            "background-color: "+ color.name()
        )

    def show_color_selector(self, button):
        initial_color = button.palette().color(QPalette.Base)
        color = QColorDialog.getColor(initial=initial_color)
        if color.isValid():
            button.setStyleSheet("background-color: "+ color.name())
            h, s, v, _ = color.getHsv()
            self.gate_mask_color_slider.setValue(v)


"""
Default Settings
"""


class DefaultSettings(QDialog):
    dlg_instance = None

    @classmethod
    def show_dialog(cls, parent):
        try:
            cls.dlg_instance.close()
            cls.dlg_instance.deleteLater()
        except:
            pass

        cls.dlg_instance = DefaultSettings(parent)
        cls.dlg_instance.show()

    def __init__(self, parent=None):
        super(DefaultSettings, self).__init__(parent)

        self.parentUI = parent
        
        self.setWindowFlags(self.windowFlags() | Qt.WindowCloseButtonHint)
        self.setWindowTitle("Default Attributes")

        self.create_layouts()
        self.create_widgets()
        self.create_connections()

        self.setFixedSize(DPI(320), self.sizeHint().height())


    def create_layouts(self):
        self.main_layout = QFormLayout()
        self.main_layout.setVerticalSpacing(DPI(10))
        self.setLayout(self.main_layout)

    def create_widgets(self):
        onlyFloat = QRegExpValidator(QRegExp(r"[0-9].+"))

        description_label = QLabel("Mark the default attributes you want to be saved.")
        description_label.setAlignment(Qt.AlignCenter)

        self.near_clip_plane = QLineEdit()
        self.far_clip_plane = QLineEdit()
        self.near_clip_plane.setText(str(self.parentUI.default_near_clip_plane[0]))
        self.far_clip_plane.setText(str(self.parentUI.default_far_clip_plane[0]))

        self.near_clip_plane.setEnabled(self.parentUI.default_near_clip_plane[1])
        self.far_clip_plane.setEnabled(self.parentUI.default_far_clip_plane[1])

        self.overscan_slider = QSlider(Qt.Horizontal)
        self.overscan_value = QLineEdit()
        self.overscan_slider.setRange(1000, 2000)
        self.overscan_slider.setValue((float(self.parentUI.default_overscan[0]) * 1000))
        self.overscan_value.setText(str(self.get_float(self.overscan_slider.value())))

        self.overscan_slider.setEnabled(self.parentUI.default_overscan[1])
        self.overscan_value.setEnabled(self.parentUI.default_overscan[1])

        self.gate_mask_opacity_slider = QSlider(Qt.Horizontal)
        self.gate_mask_opacity_slider.setRange(0, 1000)
        self.gate_mask_opacity_slider.setValue(
            int(float(self.parentUI.default_gate_mask_opacity[0]) * 1000)
        )

        self.gate_mask_opacity_value = QLineEdit()
        self.gate_mask_opacity_value.setText(
            str(self.get_float(self.gate_mask_opacity_slider.value()))
        )

        self.gate_mask_opacity_slider.setEnabled(self.parentUI.default_gate_mask_opacity[1])
        self.gate_mask_opacity_value.setEnabled(self.parentUI.default_gate_mask_opacity[1])

        overscan_container = QHBoxLayout()
        overscan_container.addWidget(self.overscan_value)
        overscan_container.addWidget(self.overscan_slider)

        gate_mask_opacity_container = QHBoxLayout()
        gate_mask_opacity_container.addWidget(self.gate_mask_opacity_value)
        gate_mask_opacity_container.addWidget(self.gate_mask_opacity_slider)

        color_slider_and_picker = QHBoxLayout()
        self.gate_mask_color_slider = QSlider(Qt.Horizontal)
        self.gate_mask_color_slider.setRange(0, 255)
        self.gate_mask_color_slider.setValue(128)
        self.gate_mask_color_picker = QPushButton()
        self.gate_mask_color_picker.setFixedWidth(DPI(80))
        self.gate_mask_color_picker.setFixedHeight(DPI(17))

        self.gate_mask_color_picker.setEnabled(self.parentUI.default_gate_mask_color[1])
        self.gate_mask_color_slider.setEnabled(self.parentUI.default_gate_mask_color[1])

        self.update_button_color()

        color_slider_and_picker.addWidget(self.gate_mask_color_picker)
        color_slider_and_picker.addWidget(self.gate_mask_color_slider)

        self.near_clip_plane.setValidator(onlyFloat)
        self.far_clip_plane.setValidator(onlyFloat)
        self.overscan_value.setValidator(onlyFloat)
        self.gate_mask_opacity_value.setValidator(onlyFloat)

        self.near_clip_plane.setFixedWidth(DPI(80))
        self.far_clip_plane.setFixedWidth(DPI(80))
        self.overscan_value.setFixedWidth(DPI(80))
        self.gate_mask_opacity_value.setFixedWidth(DPI(80))

        ok_close_layout = QHBoxLayout()
        self.ok_btn = QPushButton("OK")
        self.close_btn = QPushButton("Close")
        ok_close_layout.addWidget(self.ok_btn)
        ok_close_layout.addWidget(self.close_btn)

        layout_dict = {
            "Near Clip Plane": self.near_clip_plane,
            "Far Clip Plane": self.far_clip_plane,
            "Overscan": overscan_container,
            "Gate Mask Opacity": gate_mask_opacity_container,
            "Gate Mask Color": color_slider_and_picker,
        }

        self.main_layout.addRow(description_label)
        self.main_layout.addRow(QFrame(frameShape=QFrame.HLine))
        # Loop through each key-value pair in the dictionary and add it to the layout with a checkbox
        for index, (key, value) in enumerate(layout_dict.items()):
            if index == 2:
                self.main_layout.addRow(QFrame(frameShape=QFrame.HLine))

            widget_container = QHBoxLayout()
            widget_container.setSpacing(DPI(5))
            checkbox = QCheckBox()
            checkbox.setFixedWidth(DPI(15))
            widget_container.addWidget(checkbox)
            label = QLabel(key)
            label.setFixedWidth(DPI(100))
            widget_container.addWidget(label)
            if isinstance(value, QLayout):
                for i in range(value.count()):
                    widget = value.itemAt(i).widget()
                    if isinstance(widget, QWidget):
                        checkbox.setChecked(widget.isEnabled())
                        checkbox.toggled.connect(
                            lambda checked=checkbox.isChecked(), v=widget: v.setEnabled(
                                checked
                            )
                        )
                widget_container.addLayout(value)
            if isinstance(value, QWidget):
                checkbox.setChecked(value.isEnabled())
                checkbox.toggled.connect(
                    lambda checked=checkbox.isChecked(), v=value: v.setEnabled(checked)
                )
                widget_container.addWidget(value)
            self.main_layout.addRow(widget_container)

        self.main_layout.addRow(ok_close_layout)

    def create_connections(self):
        self.overscan_slider.valueChanged.connect(
            lambda: self.overscan_value.setText(str(self.get_float(self.overscan_slider.value())))
        )

        self.gate_mask_opacity_slider.valueChanged.connect(
            lambda: self.gate_mask_opacity_value.setText(
                self.get_float(self.gate_mask_opacity_slider.value())
            )
        )

        self.gate_mask_color_picker.clicked.connect(
            lambda: self.show_color_selector(self.gate_mask_color_picker)
        )

        self.gate_mask_color_slider.valueChanged.connect(
            lambda: self.update_button_value(self.gate_mask_color_slider.value())
        )

        all_widgets = [
            self.near_clip_plane,
            self.far_clip_plane,
            self.overscan_value,
            self.gate_mask_opacity_value,
        ]

        for widget in all_widgets:
            widget.returnPressed.connect(self.apply_settings)

        self.ok_btn.clicked.connect(partial(self.apply_settings, close=True))
        self.close_btn.clicked.connect(lambda: self.close())

    def get_float(self, value):
        return "{:.3f}".format(value / 1000.0)

    def update_button_color(self):
        rgb = self.parentUI.default_gate_mask_color[0]
        qcolor = QColor(*[int(q * 255) for q in rgb])
        h, s, v, _ = qcolor.getHsv()
        qcolor.setHsv(h, s, v)
        self.gate_mask_color_picker.setStyleSheet(
            "background-color: "+ qcolor.name()
        )
        self.gate_mask_color_slider.setValue(v)

    def update_button_value(self, value):
        color = self.gate_mask_color_picker.palette().color(QPalette.Button)
        h, s, v, _ = color.getHsv()
        color.setHsv(h, s, value)
        self.gate_mask_color_picker.setStyleSheet(
            "background-color: "+ color.name()
        )

    def show_color_selector(self, button):
        initial_color = button.palette().color(QPalette.Base)
        color = QColorDialog.getColor(initial=initial_color)
        if color.isValid():
            button.setStyleSheet("background-color: "+ color.name())
            h, s, v, _ = color.getHsv()
            self.gate_mask_color_slider.setValue(v)

    def apply_settings(self, close=False):
        near = float(self.near_clip_plane.text()), self.near_clip_plane.isEnabled()
        far = float(self.far_clip_plane.text()), self.far_clip_plane.isEnabled()
        overscan = float(self.overscan_value.text()), self.overscan_value.isEnabled()
        mask_op = (
            float(self.gate_mask_opacity_value.text()),
            self.gate_mask_opacity_value.isEnabled(),
        )
        r, g, b, _ = (
            self.gate_mask_color_picker.palette().color(QPalette.Button).getRgb()
        )
        mask_color = [
            round(x / 255.0, 3) for x in [r, g, b]
        ], self.gate_mask_color_picker.isEnabled()

        self.parentUI.process_prefs(near=near,
                                    far=far,
                                    overscan=overscan,
                                    mask_op=mask_op,
                                    mask_color=mask_color)
        if self.parentUI.default_cam[1]:
            self.parentUI.default_cam_btn.setText(self.parentUI.default_cam[0])
        if close:
            self.close()


"""
Coffee window
"""


class Coffee(QMessageBox):
    def __init__(self, version):
        super(Coffee, self).__init__()

        base64Data = "/9j/4AAQSkZJRgABAQAAAQABAAD/4QAqRXhpZgAASUkqAAgAAAABADEBAgAHAAAAGgAAAAAAAABHb29nbGUAAP/bAIQAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFAEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBMUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAIAAgAwERAAIRAQMRAf/EABkAAQEAAwEAAAAAAAAAAAAAAAcIBAUGA//EACwQAAEEAQIFAwIHAAAAAAAAAAECAwQRBQYSAAcIEyEiMUFRYRQXMkJTcdH/xAAbAQACAgMBAAAAAAAAAAAAAAAHCAUJAwQGAf/EADMRAAEDAgQEBAQFBQAAAAAAAAECAxEEIQAFEjEGQVFhB3GBoRMikcEUUrHR8CMkMkKC/9oADAMBAAIRAxEAPwBMTk04Rt2a73iwwkrcTHZW84oD4S2gKUo/QJBPDD1rqWWFOKSVRyAk4r64fbdqcwbp23Ut6jErVpT6n9Le04DdRdXULV+YaY0jraJjWEqUFRcjGfipWgD004pKNzilV43gAK9lbfK15tnNdXVDigpSGv8AUJUAQOqikzfcjbl1JsX4e4To8pomkOIQt8f5qWglJJ5I1AC2wNp3IvGMmZ1Kaq0TiX52Oy6ZsxlAWuDkkLWknxdtqWSUfdpY+nnzxG0WaZhTODS8VJnZR1A+puPqOuJ+uynLX25LISoflGg/QWPnfFhcrtfsczeWmltXx2Uxm81Aalqjpc7gZcIpxvdQ3bVhSboXXsODDTO/iWg51wJ3CaZ5TKjsYwaYxtxWSjBlG93uJ2pPizfgcEWqWlFO4tatIAMnpbf0whWWoW9WsNtN/EUpaQEzGolQhM8pNp5Y9dTdL2L1viUymtOQYUl38S/PLUJp9yQvuLIKVFVW4ACNxFbxuAIIClIV/ckSCkmdRvHPy9t8WwLdIohqKkqQAAgEJmIHcjsJ2xInU9034flVAwLaMw+xLnyi21go0r1BPkdwIBpPkijQ/VXzxnYe1VBTII6xyx49TlVAXdBFhuZv0nmcUv0XtL0pyQh6bfeEl3HzH3DITVOd5Xe+PkFZH3q/mgV+HHBU0ytIjSY9gfvgDcSqNDXIC1SVpnyuR9sbPC5VnM4yHlIal9iQgOtlSSlQsX5HweCVQ11Nm1KHmTqQrcH3BH6/thJ87ybMuFM0XQVo0PNkEEGx5pWhVrHcGxBsYUCB0M/X3MBnDpwumdPOZtx5oNsZBqWywzEtSrMkuGwkWPWEuGgAGybJXfP8nZy3M3WdWls/MkdjuB5GfSMWD+HnFj3E3DtPWuJ+JUIJbcJkypAEExeVJgmI+YkzEAAXNblvhovPLQULNsxcjlZjiXJZYBbakPNRXHnFBPg7N7QofQgH54x8LUjdbmTbCh/TJMjsEkj3jEz4lZ/W5NwvUV7bhDqQkJ5wVOJTaexOGnBZJvBNNQ48duLDbG1DbIoJ/wB/v34ZFvLWKdkNU6dIHLCCN8W1tVVGor1lalbn+cuw2wfa61V+UuIm5ZEbv4kJLiGN5Cd/8RNHZZPpPmhYqkgEaOUdZw/nCXqITTvH5hyBuT5dUn/nYDBnymvyrxL4WOV50rTmNImG3N1qTYJPLV+VwE7wuQVWP+R/UxqfI6zU7LisZuLkEOJh41qmkR1NpWu0GlE2EkEqJ/b5HgcaXFtInMqP8cpUKb7bgkCPQ3+vUYKXh3TU/Cr5yqkSSl66iTfUATJ5XFoAGw3ucAevubuvub3PsaoabVpqZhlKjwURyHRGJ9Cxak04VBRCrFV4r3uG4cy59pSXW5TBmY35fS/rOOu4yqqDMmHMvqQHUKEFM23mZBnUCAbGxHnLjh+oHPY/JoGpsdClY9e1C3cSwtpxo3RXtW4sLH2FHwas0kmtuvUD84kdsKfmPh5S/BJy5xQcF4WQQe0pSnSe5kdYEkf/2Q=="
        if get_python_version() < 3:
            image_64_decode = base64.decodestring(base64Data)
        else:
            image_64_decode = base64.decodebytes(base64Data.encode("utf-8"))
        image = QImage()
        image.loadFromData(image_64_decode, "JPG")
        pixmap = QPixmap(image).scaledToHeight(
            DPI(56), Qt.SmoothTransformation
        )
        self.setIconPixmap(pixmap)

        self.setWindowTitle("About")
        self.setText(
            '<p><font color="white">Cams - '+version+'</p>By @Aleha - <a href=https://www.instagram.com/alejandro_anim><font color="white">Instagram</a><br>My website - <a href=https://alehaaaa.github.io><font color="white">alehaaaa.github.io</a><br><br>If you liked this set of tools,<br>you can send me some love!'
        )
        self.setFixedSize(DPI(400), DPI(300))