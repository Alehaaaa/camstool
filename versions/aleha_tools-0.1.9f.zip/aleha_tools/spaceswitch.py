"""

Put this file in your scripts directory:
"%USERPROFILE%\Documents\maya\####\scripts"
or
"%USERPROFILE%\Documents\maya\scripts"


Run with:

import aleha_tools.spaceswitch as spaceswitch
spaceswitch.UI.show_dialog()


"""

try:
    from PySide2.QtWidgets import *
    from PySide2.QtGui import *
    from PySide2.QtCore import *
    from shiboken2 import wrapInstance

except ImportError:
    from PySide6.QtWidgets import *
    from PySide6.QtGui import *
    from PySide6.QtCore import *
    from shiboken6 import wrapInstance

import maya.OpenMayaUI as omui, maya.OpenMaya as om
import maya.cmds as cmds, maya.mel as mel
import base64, sys, os


MAINTAINANCE = False

def get_maya_win():
    win_ptr = omui.MQtUtil.mainWindow()
    if sys.version_info.major < 3: return wrapInstance(long(win_ptr), QMainWindow)
    else: return wrapInstance(int(win_ptr), QMainWindow)

def show():
    if MAINTAINANCE and os.getenv('USERNAME') != 'alejandro':
        cmds.error('Script in MAINTAINANCE')
        return
    
    global spaceswitch_aleha_tool
    if "spaceswitch_aleha_tool" in globals():
        try:
            try:spaceswitch_aleha_tool.kill_all_scriptJobs()
            except:pass
            spaceswitch_aleha_tool.close()
            spaceswitch_aleha_tool.deleteLater()

            del spaceswitch_aleha_tool
        except:pass
    spaceswitch_aleha_tool = UI()

    if spaceswitch_aleha_tool.isHidden():
        spaceswitch_aleha_tool.show()
    else:
        spaceswitch_aleha_tool.raise_()
        spaceswitch_aleha_tool.activateWindow()

    spaceswitch_aleha_tool.add_scriptJobs()
    spaceswitch_aleha_tool.refresh()



class UI(QDialog):
    TITLE = "SpaceSwitch"
    VERSION = "0.9d"
    """
    Messages:
    """
    NO_INTERNET = "Could not establish a connection to the server."
    WORKING_ON_IT = "Still working on this feature!"

    def __init__(self, parent=None):
        super(UI, self).__init__(parent=get_maya_win())

        self.setWindowTitle(("{} {}").format(UI.TITLE, UI.VERSION))
        if sys.platform == 'darwin': self.setWindowFlags(Qt.Tool)
        else: self.setWindowFlags(Qt.Window | Qt.WindowCloseButtonHint)

        self.setModal(False)
        self.setMaximumWidth(self.width())
        self.setMaximumHeight(self.height())

        self.show_namespace_name = False
        self.show_rotate_order_attribute = True

        self.selected_attr = None

        self.create_layouts()
        self.create_widgets()
        self.create_connections()

        #self.check_for_updates(warning=False)

    def create_layouts(self):
        self.main_layout = QVBoxLayout(self)

        # Menu bar
        menu_bar = QMenuBar()
        settings_menu = menu_bar.addMenu("Settings")
        self.toggle_namespaces_action = settings_menu.addAction("Show namespaces")
        self.toggle_namespaces_action.setCheckable(True)
        self.toggle_namespaces_action.setChecked(self.show_namespace_name)

        self.show_rotate_order_action = settings_menu.addAction("Enable Rotate Order")
        self.show_rotate_order_action.setCheckable(True)
        self.show_rotate_order_action.setChecked(self.show_rotate_order_attribute)

        settings_menu.addSeparator()
        self.all_frames_action = settings_menu.addAction("Apply to all frames")
        self.all_frames_action.setCheckable(True)
        self.all_frames_action.setChecked(False)

        menu_about = menu_bar.addMenu("About")
        self.check_updates_action = menu_about.addAction("Check for updates")
        self.check_updates_action.setVisible(False)
        menu_about.addSeparator()
        self.credits_action = menu_about.addAction("Credits")

        self.main_layout.setMenuBar(menu_bar)

        self.enums_layout = QVBoxLayout()
        self.button_layout = QHBoxLayout()
        self.main_layout.addLayout(self.enums_layout)
        self.main_layout.addLayout(self.button_layout)

    def create_widgets(self):
        self.selection_label = QLabel("No valid switches selected.")
        self.selection_label.setStyleSheet("QLabel {background-color: #333333;border-radius: 3px;}")
        self.selection_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.selection_label.setFixedHeight(21)
        self.main_layout.insertWidget(0, self.selection_label)

    def create_connections(self):
        self.toggle_namespaces_action.triggered.connect(self.set_namespaces_display)
        self.show_rotate_order_action.triggered.connect(self.set_rotate_order_display)
        self.check_updates_action.triggered.connect(self.check_for_updates)
        self.credits_action.triggered.connect(self.coffee)

    def set_namespaces_display(self):
        self.show_namespace_name = self.toggle_namespaces_action.isChecked()
        self.refresh()

    def set_rotate_order_display(self):
        self.show_rotate_order_attribute = self.show_rotate_order_action.isChecked()
        self.refresh()

    def getSelectedObj(self, long=False):
        return cmds.ls(selection=True, long=long)

    # Main Function to Set the ComboBox
    def set_combobox(self, enum_objects):
        combobox = QComboBox()
        combobox.setMaxVisibleItems(60)
        combobox.setItemDelegate(RightIconDelegate(combobox))
        
        # Track unique options and currents
        seen, currents = set(), {item for obj in enum_objects.values() for item in obj.get('currents', [])}
        
        for i, op in enumerate([enum for obj in enum_objects.values() for enum in obj['enum'] if not (enum in seen or seen.add(enum))]):
            combobox.addItem(op)
            # Set Qt.UserRole to mark current options
            if i in currents:
                combobox.setItemData(i, True, Qt.UserRole)
                combobox.setCurrentText(op)
        
        combobox.insertSeparator(combobox.count())

        seen = set()

        for i, op in enumerate([enum for obj in enum_objects.values() for enum in obj['enum'] if not (enum in seen or seen.add(enum))]):
            combobox.addItem(op)
            # Set Qt.UserRole to mark current options
            if i in currents:
                combobox.setItemData(combobox.count() - 1, True, Qt.UserRole)
                combobox.setCurrentText(op)
        
        return combobox

    def getEnums(self):
        global spaceswitch_enum_dictionary
        if 'spaceswitch_enum_dictionary' in globals():
            del spaceswitch_enum_dictionary
        spaceswitch_enum_dictionary = {}

        current_time = cmds.currentTime(q=1)

        sel = self.getSelectedObj(long=True)
        for object in sel:
            if object in spaceswitch_enum_dictionary.keys():
                continue

            locked = cmds.listAttr(object, cb=1) or []
            animatable = cmds.listAnimatable(object)
            if animatable:
                orderedAttrs = [i.rsplit(".", 1)[-1] for i in animatable if i and i not in locked]

                if orderedAttrs:
                    if self.show_rotate_order_attribute:
                        orderedAttrs.extend(["rotateOrder"])
                    for enum_attr in orderedAttrs:
                        try: attrType = cmds.attributeQuery(enum_attr, node=object, attributeType=True)
                        except: continue
                        if attrType == "enum":
                            enum_values = cmds.attributeQuery(enum_attr, node=object, listEnum=True)[0].split( ":" )
                            long_name = cmds.attributeQuery(enum_attr, node=object, niceName=True)
                            if any(c.isalnum() for c in enum_values):
                                if not enum_attr in spaceswitch_enum_dictionary.keys():
                                    spaceswitch_enum_dictionary[enum_attr] = {'objects': {}, 'long': long_name}
                                if not object in spaceswitch_enum_dictionary[enum_attr].keys():
                                    spaceswitch_enum_dictionary[enum_attr]['objects'][object] = {'enum': [], 'currents': []}
                                for value in enum_values:
                                    spaceswitch_enum_dictionary[enum_attr]['objects'][object]['enum'].append(value)
                                keys = cmds.keyframe(f"{object}.{enum_attr}", query=True, valueChange=True) or []
                                spaceswitch_enum_dictionary[enum_attr]['objects'][object]['currents'] = list(set([int(x) for x in keys])) or [cmds.getAttr(f"{object}.{enum_attr}")]
                                
        return spaceswitch_enum_dictionary

    def refresh(self, timeChange=False, *args):
        if timeChange:
            return
        self.selection_label.setHidden(False)
        try:
            sel = self.getSelectedObj()
            self.clearlayout(self.enums_layout)
            if sel:
                
                self.getEnums()
                if spaceswitch_enum_dictionary:
                    self.selection_label.setHidden(True)

                    for enum, enum_objects_current in spaceswitch_enum_dictionary.items():
                        combobox_layout = QHBoxLayout()
                        unique_controls = list(set(enum_objects_current['objects'].keys()))
                        if len(unique_controls) == 1:
                            combobox_name = unique_controls[0]
                            combobox_name = combobox_name.split('|')[-1]
                            if ':' in combobox_name and not self.show_namespace_name: combobox_name = combobox_name.split(':')[-1]
                        else: combobox_name = f"({len(unique_controls)})"

                        control_target = QLabel("%s %s" % (combobox_name, enum_objects_current['long'].title()))
                        combobox_layout.addWidget(control_target)

                        combobox = self.set_combobox(enum_objects_current['objects'])
                        combobox_layout.addWidget(combobox)

                        options_and_objects = {}
                        for obj, option in enum_objects_current['objects'].items():
                            for i, o in enumerate(option['enum']):
                                if o not in options_and_objects.keys():
                                    options_and_objects[o] = {"objects":[]}
                                options_and_objects[o]["objects"].append(obj)
                                options_and_objects[o]["index"] = i

                        combobox.textActivated.connect(lambda x, enum=enum, oo=options_and_objects: self.apply_changes(x, enum, oo))
                        self.enums_layout.insertLayout(0, combobox_layout)
        finally:
            self.adjustSize()

    def clearlayout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
            if child.layout():
                self.clearlayout(child.layout())
        
    @staticmethod
    def do_xform(target, enum_attr, enum_value, xform=None):
        xform = xform or cmds.xform(target, q=True, ws=True, matrix=True)
        cmds.setAttr(("{}.{}").format(target, enum_attr), enum_value)
        cmds.xform(target, ws=True, matrix=xform)

    def multiple_frames(self, enum_attr, enum_value, keyframes):
        marker_widget = None

        try:
            # Color timeline
            timerange = [list(keyframes.keys())[0], list(keyframes.keys())[-1] +1]
            if cmds.timeControl("timeControl1", q=1, rv=1):
                timerange = [int(f) for f in cmds.timeControl("timeControl1", ra=1, q=True)]

            if int(cmds.about(v=1)) >= 2024:
                cmds.playbackOptions( sv=False )

            timeline_wgt = TimelineMarker().get_timeline()
            marker_widget = TimelineMarker(timerange, parent=timeline_wgt)
            marker_widget.setGeometry(timeline_wgt.rect())
            marker_widget.show()
            
            # Start Progress Bar
            gMainProgressBar = mel.eval("$tmp = $gMainProgressBar")
            bar_value = 1
            max_bar_value = len(keyframes.keys())
            cmds.progressBar(gMainProgressBar, e=True, bp=True, max=max_bar_value)

            dictionary_xforms = {}
            current_time = cmds.currentTime(q=True)
            for frame, targets in keyframes.items():
                cmds.currentTime(frame)
                dictionary_xforms[frame] = {}
                for t in targets:
                    dictionary_xforms[frame][t] = cmds.xform(t, q=True, ws=True, matrix=True)
                cmds.progressBar(
                    gMainProgressBar,
                    edit=True,
                    status="Saving Positions (%s/%s)..."
                    % (bar_value, max_bar_value),
                    step=1,
                )
                bar_value += 1
            bar_value = 1
            cmds.progressBar(gMainProgressBar, e=True, ep=True)
            cmds.progressBar(gMainProgressBar, e=True, bp=True, max=max_bar_value)
            for frame, targets in dictionary_xforms.items():
                for target, xform in targets.items():
                    cmds.currentTime(frame)
                    self.do_xform(target, enum_attr, enum_value, xform)
                    cmds.progressBar(
                        gMainProgressBar,
                        edit=True,
                        status="Applying Positions (%s/%s)..."
                        % (bar_value, max_bar_value),
                        step=1,
                    )
                    bar_value += 1

            cmds.currentTime(current_time)
            cmds.progressBar(gMainProgressBar, e=True, ep=True)

        finally:
            if marker_widget:
                marker_widget.delete_marker()
                marker_widget = None

    def apply_changes(self, enum_value, enum_attr, options_and_objects):
        targets = options_and_objects[enum_value]["objects"]
        enum_index = options_and_objects[enum_value]["index"]

        cmds.undoInfo(openChunk=True)
        self.kill_all_scriptJobs()

        cmds.refresh(suspend=True)

        timeline_selection = cmds.timeControl("timeControl1", q=True, rv=True)
        current_frames = cmds.timeControl("timeControl1", q=True, ra=True)

        if not timeline_selection and not self.all_frames_action.isChecked():
            targets_with_keys = targets
            keyframes = current_frames
        else:
            keyframes = {k: [t for t in targets if k in cmds.keyframe(t, query=True) or []] for k in sorted(set(sum([cmds.keyframe(t, query=True) or [] for t in targets], [])))}
            if timeline_selection:
                keyframes = {k: v for k, v in keyframes.items() if current_frames[0] <= k <= current_frames[1]}            

            targets_with_keys = list(set([object for _list in keyframes.values() for object in _list]))
        
        sorted_targets_with_keys = sorted(targets_with_keys, key=lambda x: x.count('|'), reverse=True)
        try:

            # Check if there is a timeline selection.
            if sorted_targets_with_keys:
                if type(keyframes) == dict:
                    self.multiple_frames(enum_attr, enum_index, keyframes)
                elif type(keyframes) == list:
                    cmds.currentTime(keyframes[0])
                    for target in sorted_targets_with_keys:
                        self.do_xform(target, enum_attr, enum_index)
            else:
                for target in sorted_targets_with_keys:
                    self.do_xform(target, enum_attr, enum_index)

        finally:
            cmds.refresh(suspend=False)
            self.add_scriptJobs()
            self.refresh()

            cmds.undoInfo(closeChunk=True)
            
        cmds.showWindow( 'MayaWindow' )

    # Check for Updates
    def check_for_updates(self, warning=True, *args):
        import json

        script_name = self.TITLE.lower()

        url = "https://raw.githubusercontent.com/Alehaaaa/mayascripts/main/version.json"

        if sys.version_info.major < 3:
            from urllib2 import urlopen
        else:
            from urllib.request import urlopen

        try:
            response = urlopen(url, timeout=1)
        except:
            if warning:
                om.MGlobal.displayWarning(UI.NO_INTERNET)
            return
        content = response.read()

        if content:
            data = json.loads(content)
            script = data[script_name]

            version = str(script["version"])
            changelog = script["changelog"]

        def convert_list_to_string():
            result, sublst = [], []
            for item in changelog:
                if item:
                    sublst.append(str(item))
                else:
                    if sublst:
                        result.append(sublst)
                        sublst = []
            if sublst:
                result.append(sublst)
            result = result[:4]
            result.append(["== And more =="])
            return "\n\n".join(["\n".join(x) for x in result])

        if version > self.VERSION:
            update_available = cmds.confirmDialog(
                title="New update for {0}!".format(self.TITLE),
                message="Version {0} available, you are using {1}\n\nChangelog:\n{2}".format(
                    version, self.VERSION, convert_list_to_string()
                ),
                messageAlign="center",
                button=["Install", "Close"],
                defaultButton="Install",
                cancelButton="Close",
            )
            if update_available == "Install":

                self.kill_all_scriptJobs()
                self.deleteLater()
                cmds.evalDeferred(
                    "import aleha_tools.{} as spaceswitch;try:from importlib import reload;except:pass;reload(spaceswitch);spaceswitch.UI.show_dialog();".format(
                        script_name
                    )
                )
        else:
            if warning:
                om.MGlobal.displayWarning("All up-to-date.")

    def coffee(self):
        aleha_credits = QMessageBox()
        base64Data = "/9j/4AAQSkZJRgABAQAAAQABAAD/4QAqRXhpZgAASUkqAAgAAAABADEBAgAHAAAAGgAAAAAAAABHb29nbGUAAP/bAIQAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFAEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBMUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAIAAgAwERAAIRAQMRAf/EABkAAQEAAwEAAAAAAAAAAAAAAAcIBAUGA//EACwQAAEEAQIFAwIHAAAAAAAAAAECAwQRBQYSAAcIEyEiMUFRYRQXMkJTcdH/xAAbAQACAgMBAAAAAAAAAAAAAAAHCAUJAwQGAf/EADMRAAEDAgQEBAQFBQAAAAAAAAECAxEEIQAFEjEGQVFhB3GBoRMikcEUUrHR8CMkMkKC/9oADAMBAAIRAxEAPwBMTk04Rt2a73iwwkrcTHZW84oD4S2gKUo/QJBPDD1rqWWFOKSVRyAk4r64fbdqcwbp23Ut6jErVpT6n9Le04DdRdXULV+YaY0jraJjWEqUFRcjGfipWgD004pKNzilV43gAK9lbfK15tnNdXVDigpSGv8AUJUAQOqikzfcjbl1JsX4e4To8pomkOIQt8f5qWglJJ5I1AC2wNp3IvGMmZ1Kaq0TiX52Oy6ZsxlAWuDkkLWknxdtqWSUfdpY+nnzxG0WaZhTODS8VJnZR1A+puPqOuJ+uynLX25LISoflGg/QWPnfFhcrtfsczeWmltXx2Uxm81Aalqjpc7gZcIpxvdQ3bVhSboXXsODDTO/iWg51wJ3CaZ5TKjsYwaYxtxWSjBlG93uJ2pPizfgcEWqWlFO4tatIAMnpbf0whWWoW9WsNtN/EUpaQEzGolQhM8pNp5Y9dTdL2L1viUymtOQYUl38S/PLUJp9yQvuLIKVFVW4ACNxFbxuAIIClIV/ckSCkmdRvHPy9t8WwLdIohqKkqQAAgEJmIHcjsJ2xInU9034flVAwLaMw+xLnyi21go0r1BPkdwIBpPkijQ/VXzxnYe1VBTII6xyx49TlVAXdBFhuZv0nmcUv0XtL0pyQh6bfeEl3HzH3DITVOd5Xe+PkFZH3q/mgV+HHBU0ytIjSY9gfvgDcSqNDXIC1SVpnyuR9sbPC5VnM4yHlIal9iQgOtlSSlQsX5HweCVQ11Nm1KHmTqQrcH3BH6/thJ87ybMuFM0XQVo0PNkEEGx5pWhVrHcGxBsYUCB0M/X3MBnDpwumdPOZtx5oNsZBqWywzEtSrMkuGwkWPWEuGgAGybJXfP8nZy3M3WdWls/MkdjuB5GfSMWD+HnFj3E3DtPWuJ+JUIJbcJkypAEExeVJgmI+YkzEAAXNblvhovPLQULNsxcjlZjiXJZYBbakPNRXHnFBPg7N7QofQgH54x8LUjdbmTbCh/TJMjsEkj3jEz4lZ/W5NwvUV7bhDqQkJ5wVOJTaexOGnBZJvBNNQ48duLDbG1DbIoJ/wB/v34ZFvLWKdkNU6dIHLCCN8W1tVVGor1lalbn+cuw2wfa61V+UuIm5ZEbv4kJLiGN5Cd/8RNHZZPpPmhYqkgEaOUdZw/nCXqITTvH5hyBuT5dUn/nYDBnymvyrxL4WOV50rTmNImG3N1qTYJPLV+VwE7wuQVWP+R/UxqfI6zU7LisZuLkEOJh41qmkR1NpWu0GlE2EkEqJ/b5HgcaXFtInMqP8cpUKb7bgkCPQ3+vUYKXh3TU/Cr5yqkSSl66iTfUATJ5XFoAGw3ucAevubuvub3PsaoabVpqZhlKjwURyHRGJ9Cxak04VBRCrFV4r3uG4cy59pSXW5TBmY35fS/rOOu4yqqDMmHMvqQHUKEFM23mZBnUCAbGxHnLjh+oHPY/JoGpsdClY9e1C3cSwtpxo3RXtW4sLH2FHwas0kmtuvUD84kdsKfmPh5S/BJy5xQcF4WQQe0pSnSe5kdYEkf/2Q=="
        if sys.version_info.major < 3:
            image_64_decode = base64.decodestring(base64Data)
        else:
            image_64_decode = base64.decodebytes(base64Data.encode("utf-8"))
        image = QImage()
        image.loadFromData(image_64_decode, "JPG")
        pixmap = QPixmap(image).scaledToHeight(56, Qt.SmoothTransformation)
        aleha_credits.setIconPixmap(pixmap)
        aleha_credits.setWindowTitle("Buy me a coffee!")
        aleha_credits.setText(
            'Created by @Aleha - <a href=https://www.instagram.com/alejandro_anim><font color="white">Instagram</a><br>My website - <a href=https://alehaaaa.github.io><font color="white">alehaaaa.github.io</a><br><br>If you liked this set of tools,<br>you can send me some love!'
        )
        aleha_credits.setFixedSize(400, 300)
        aleha_credits.exec_()

    def on_scene_opened(self, *args, **kwargs):
        # Close the dialog when a new scene is opened in Maya to avoid callback errors
        self.kill_all_scriptJobs()
        self.add_scriptJobs()

    def add_scriptJobs(self):
        cmds.scriptJob( event=["NewSceneOpened", self.on_scene_opened] )
        cmds.scriptJob( event=["SelectionChanged", self.refresh] )
        cmds.scriptJob( event=["Undo", self.refresh] )
        cmds.scriptJob( event=["timeChanged", self.refresh] )

    def kill_all_scriptJobs(self):
        for j in cmds.scriptJob(listJobs=True):
            if 'aleha_tools.spaceswitch' in j:
                if not ':' in j: continue
                id = int(j.split(':')[0])
                cmds.scriptJob(kill=int(id))

    def closeEvent(self, event):
        self.kill_all_scriptJobs()
        
        # Remove global reference
        global spaceswitch_dialog_instance
        if 'spaceswitch_dialog_instance' in globals():
            spaceswitch_dialog_instance = None
        
        self.deleteLater()
        event.accept()  # Ensure the window closes properly


# Custom Delegate Class
class RightIconDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        super().paint(painter, option, index)  # Draw default text
        
        if index.data(Qt.UserRole):  # Check if current option
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setBrush(QColor(255, 255, 255, 170))
            painter.setPen(Qt.NoPen)
            
            size = 5  # Dot size
            x = option.rect.right() - size * 2  # Position far right
            y = option.rect.center().y() - size // 2  # Center vertically
            
            painter.drawEllipse(x, y, size, size)  # Draw round dot



class TimelineMarker(QWidget):
    def __init__(self, timerange=None, parent=None):
        super(TimelineMarker, self).__init__(parent)
        self.timerange = timerange

    @staticmethod
    def get_timeline():
        tline = mel.eval("$tmpVar=$gPlayBackSlider")
        ptr = omui.MQtUtil.findControl(tline) or omui.MQtUtil.findLayout(tline) or omui.MQtUtil.findMenuItem(tline)
        if ptr:
            return wrapInstance(int(ptr), QWidget)

    def paintEvent(self, event):

        start = cmds.playbackOptions(q=True, minTime=True)
        end = cmds.playbackOptions(q=True, maxTime=True)

        total_width = self.width()
        step = (total_width - (total_width * 0.01)) / (end - start + 1)
        painter = QPainter(self)
        pen = QPen()
        pen.setWidth(step + step * 0.005)

        sframe, eframe = self.timerange
        eframe -= 1

        color_ = QColor(200, 120, 200, 70)
        pen.setColor(color_)
        pos_start = (sframe - start) * step + (total_width * 0.005)
        pos_end = (eframe + 1 - start) * step + (total_width * 0.005)
        rect = QRectF(QPointF(pos_start, 0), QPointF(pos_end, self.height()))
        painter.setPen(pen)
        painter.fillRect(rect, QBrush(color_))  # Fill the rectangle with the color


    def delete_marker(self):
        try:
            self.setParent(None)
            QPainter(self).end()
        except:
            pass


if __name__ == "__main__":
    UI().showUI()
