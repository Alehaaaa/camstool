"""

TO-DO:
    - Make it fully Python 2 compatible

    IDEAS:
    - Add HeadsUpDisplay presets

    FUTURE:

"""

DATA = {
    "TOOL": "cams",
    "VERSION": "0.2.51beta-hotfix",
    "AUTHOR": {
        "name": "Alehaaa",
        "website": "https://alehaaaa.github.io",
        "instagram": "https://www.instagram.com/alejandro_anim/",
    },
}
