"""

Run with:

import aleha_tools.cams as cams
cams.UI().showWindow()


TO-DO:
    - Make it Python 2 compatible
    
    IDEAS:
    - Add Show Viewport presets?
    
    WIP:

    FUTURE:

    DONE:
    - Add toggle to enable apply settings at launch
    - Make dagContainer icons update path at launch
    - Move settings related functions to py

"""

from functools import partial

from PySide2 import QtWidgets, QtGui, QtCore

from maya.app.general.mayaMixin import MayaQWidgetDockableMixin
import maya.OpenMayaUI as omui
import maya.OpenMaya as om
import maya.cmds as cmds, os
import webbrowser

from importlib import reload

from . import settings
from . import widgets
from . import funcs
from . import util

reload(settings)
reload(widgets)
reload(funcs)
reload(util)

from ._tools import HUDWindow as hud


class UI(MayaQWidgetDockableMixin, QtWidgets.QWidget):
    TITLE = "Cams"
    VERSION = "0.1.81beta"

    keys_pressed_changed = QtCore.Signal(list)

    def __init__(self, parent=None):
        super(self.__class__, self).__init__(parent=parent)

        self.setWindowTitle(self.TITLE)
        self.setObjectName(self.TITLE)

        self.callback_ids = []

        self.modifier_keys = [
            QtCore.Qt.Key_Control,
            QtCore.Qt.Key_Shift,
            QtCore.Qt.Key_Alt,
        ]
        self._keys_pressed = [False, False, False]

        self.settings_window = None
        self.options = None


        self.user_prefs = settings.get_all_prefs()
        self.process_prefs()

        self.create_layouts()
        self.create_widgets()
        self.create_buttons()
        self.create_menu()

        self.create_connections()
    
        self.add_callbacks()

        self.set_global_preferences()

        QtWidgets.QApplication.instance().installEventFilter(self)

    @property
    def keys_pressed(self):
        return self._keys_pressed

    @keys_pressed.setter
    def keys_pressed(self, values):
        if self._keys_pressed != values:
            self._keys_pressed = values
            self.keys_pressed_changed.emit(values)

    def collapse_workspace_control(self, *args):

        if not cmds.workspaceControl(self.objectName() + "WorkspaceControl", q=True, floating=True):
            if cmds.workspaceControl(self.objectName() + "WorkspaceControl", q=True, collapse=True):
                timer = QtCore.QTimer(self)
                timer.setSingleShot(True)

                timer.timeout.connect(
                    partial(
                        cmds.workspaceControl,
                        self.objectName() + "WorkspaceControl",
                        e=True,
                        collapse=False,
                        tp=["west", 0],
                    )
                )
                timer.start(100)

            self.dock_ui_btn.setHidden(True)
        else:
            self.dock_ui_btn.setHidden(False)
            cmds.evalDeferred(self.shelf_tabbar)

    def showWindow(self):
        # Delete any existing workspace control with the same name
        workspace_control_name = self.objectName() + "WorkspaceControl"
        if cmds.workspaceControl(workspace_control_name, q=True, exists=True):
            cmds.deleteUI(workspace_control_name)

        # Show the UI
        self.show(dockable=True, floating=True, retain=False)
        if cmds.workspaceControl(workspace_control_name, q=True, exists=True):
            self.dock_ui_btn.setHidden(True)
            if cmds.workspaceControl(workspace_control_name, q=True, floating=True):
                cmds.workspaceControl(
                    workspace_control_name,
                    e=True,
                    dockToControl=self.position,
                    tp=["west", 0],
                    rt=0,
                    r=1,
                    rsh=util.DPI(15),
                    uiScript="import maya.cmds as cmds; cmds.evalDeferred(lambda: cmds.evalDeferred('import aleha_tools.cams as cams; cams.UI().showWindow()', lowestPriority=True))",
                )

            cmds.workspaceControl(
                workspace_control_name,
                e=True,
                dockToControl=self.position,
                visibleChangeCommand=self.collapse_workspace_control,
            )
            self.raise_()

            cmds.evalDeferred(self.shelf_tabbar)

    def shelf_tabbar(self):
        try:
            if UI.shelf_painter:
                QtGui.QPainter(UI.shelf_painter).end()
                UI.shelf_painter.setParent(None)
                UI.shelf_painter.deleteLater()
                del UI.shelf_painter
        except:
            pass

        if cmds.workspaceControl(self.objectName() + "WorkspaceControl", q=True, floating=True):
            return

        qctrl = omui.MQtUtil.findControl(self.objectName() + "WorkspaceControl")
        control = util.get_maya_qt(qctrl)
        try:
            tab_handle = control.parent().parent()
        except:
            return

        UI.shelf_painter = widgets.ShelfPainter(tab_handle)
        UI.shelf_painter.setGeometry(tab_handle.geometry())
        UI.shelf_painter.move(tab_handle.tabBar().pos())

        UI.shelf_painter.show()

    """
    Setup the UI
    """

    def create_layouts(self):
        self.main_layout = QtWidgets.QHBoxLayout(self)

        self.default_cam_layout = QtWidgets.QHBoxLayout()

        self.cams_scroll = widgets.HorizontalScrollArea(util.DPI(26), self)

        cams_scroll_widget = QtWidgets.QWidget(self.cams_scroll)
        self.cams_scroll.container_layout.addWidget(cams_scroll_widget)

        self.main_layout.addLayout(self.default_cam_layout)
        self.main_layout.setContentsMargins(
            util.DPI(3), util.DPI(3), util.DPI(3), util.DPI(3)
        )
        self.main_layout.setSpacing(util.DPI(4))

    def create_widgets(self):
        self.default_cam_btn = widgets.HoverButton(self.default_cam[0], self)
        self.default_cam_layout.addWidget(self.default_cam_btn)
        self.default_cam_btn.dropped.connect(
            partial(funcs.drag_insert_camera, self.default_cam[0], self)
        )

        self.line = QtWidgets.QFrame()
        self.line.setFrameShape(QtWidgets.QFrame.VLine)
        self.line.setLineWidth(1)
        self.main_layout.addWidget(self.line)
        if util.get_cameras():
            self.line.show()
        else:
            self.line.hide()

        self.main_layout.addWidget(self.cams_scroll)

        self.dock_ui_btn = QtWidgets.QPushButton()
        self.dock_ui_btn.setToolTip("Dock to UI")
        self.dock_ui_btn.setStatusTip("Dock to UI")

        self.dock_ui_btn.setIcon(QtGui.QIcon(util.return_icon_path("dock.png")))
        self.dock_ui_btn.setFixedSize(util.DPI(15), util.DPI(15))
        self.dock_ui_btn.setStyleSheet(
            """
                            QPushButton {
                            border-radius: 20px;
                            background-color: #333;
                            padding:0;
                            margin:0;
                            }
                            QPushButton:hover {
                            background-color: #888;
                            }
                            """
        )

    def create_buttons(self):
        self.clearLayout(self.cams_scroll.container_layout)

        cameras = util.get_cameras()
        cameras = list(reversed(cameras))  # Invert the order of cameras

        # Add stretch at the beginning
        self.cams_scroll.container_layout.addStretch()

        for cam in cameras:
            button = widgets.HoverButton(cam, self)
            self.cams_scroll.container_layout.insertWidget(0, button)
            button.dropped.connect(partial(funcs.drag_insert_camera, cam, self))

    # Menu bar layout

    def create_menu(self):
        menu_bar = QtWidgets.QMenuBar()
        menu_bar.setFixedHeight(util.DPI(18))

        menu_general = QtWidgets.QMenu("General")
        menu_general.setTearOffEnabled(True)
        menu_bar.addMenu(menu_general)

        title_action = QtWidgets.QWidgetAction(self)
        title_label = QtWidgets.QLabel("CAMS %s" % self.VERSION)
        title_label.setFixedHeight(util.DPI(32))
        title_label.setContentsMargins(util.DPI(20), 0, util.DPI(20), 0)
        title_label.setStyleSheet(
            "font-size: " + str(util.DPI(15)) + "px; font-weight: bold;"
        )
        title_label.setCursor(QtCore.Qt.PointingHandCursor)
        title_action.setDefaultWidget(title_label)
        title_action.triggered.connect(partial(webbrowser.open, "alehaaaa.github.io"))
        menu_general.addAction(title_action)

        self.reload_btn = menu_general.addAction(
            QtGui.QIcon(util.return_icon_path("refresh.png")), "Refresh Cameras"
        )
        menu_general.addSeparator()

        self.about = menu_general.addAction(
            QtGui.QIcon(util.return_icon_path("info.png")), "About"
        )
        self.updates = menu_general.addAction(
            QtGui.QIcon(util.return_icon_path("updates.png")), "Check for Updates"
        )

        menu_general.addSeparator()

        self.settings_btn = menu_general.addAction(
            QtGui.QIcon(util.return_icon_path("default_attributes.png")),
            "Default Attributes",
        )
        menu_general.addSeparator()

        ## DOCK TAB ##

        dock_menu = QtWidgets.QMenu("Dock Window")
        dock_menu.setIcon(QtGui.QIcon(util.return_icon_path("dock.png")))
        dock_menu.setTearOffEnabled(True)

        self.pos_ac_group = QtWidgets.QActionGroup(self)
        self.docking_orients = {
            "top": "To Top",
            "bottom": "To Bottom",
        }
        for orient, name in self.docking_orients.items():
            ori_btn = QtWidgets.QAction(name, self)
            ori_btn.setCheckable(True)
            self.pos_ac_group.addAction(ori_btn)
            dock_menu.addAction(ori_btn)
            ori_btn.triggered.connect(partial(self.dock_to_ui, orient=orient))
            if orient == self.position[1]:
                ori_btn.setChecked(True)
                ori_btn.setEnabled(False)

        dock_menu.addSeparator()

        self.dock_ac_group = QtWidgets.QActionGroup(self)
        self.docking_layouts = {
            "AttributeEditor": "Attribute Editor",
            "ChannelBoxLayerEditor": "Channel Box",
            "Outliner": "Outliner",
            "MainPane": "Main Viewport",
            "TimeSlider": "Time Slider",
            "RangeSlider": "Range Slider",
            "Shelf": "Shelf",
        }

        for layout, name in self.docking_layouts.items():
            dock_btn = QtWidgets.QAction(name, self)
            dock_btn.setCheckable(True)
            self.dock_ac_group.addAction(dock_btn)
            dock_menu.addAction(dock_btn)
            dock_btn.setEnabled(True)
            dock_btn.triggered.connect(partial(self.dock_to_ui, layout=layout))
            if layout == self.position[0]:
                dock_btn.setChecked(True)
                dock_btn.setEnabled(False)

        menu_general.addMenu(dock_menu)

        ## SETTINGS TAB ##

        system_menu = widgets.OpenMenu("System")
        system_menu.setIcon(QtGui.QIcon(util.return_icon_path("system.png")))
        system_menu.setTearOffEnabled(True)

        self.startup_Viewport_checkbox = system_menu.addAction("Viewport on Startup")
        self.startup_Viewport_checkbox.setToolTip(
            "Apply Show settings to Viewports on Startup"
        )
        self.startup_Viewport_checkbox.setStatusTip(
            "Apply Show settings to Viewports on Startup"
        )
        self.startup_Viewport_checkbox.setCheckable(True)
        self.startup_Viewport_checkbox.setChecked(self.startup_viewport)
        self.startup_Viewport_checkbox.triggered.connect(
            lambda state=self.startup_Viewport_checkbox.isChecked(): self.process_prefs(
                startup_viewport=state
            )
        )

        self.startup_HUD_checkbox = system_menu.addAction("HUD on Startup")
        self.startup_HUD_checkbox.setCheckable(True)
        self.startup_HUD_checkbox.setChecked(self.startup_hud)
        self.startup_HUD_checkbox.triggered.connect(
            lambda state=self.startup_HUD_checkbox.isChecked(): self.process_prefs(
                startup_hud=state
            )
        )

        system_menu.addSeparator()

        self.reset_cams_data = system_menu.addAction(
            QtGui.QIcon(util.return_icon_path("remove.png")), "Reset All Settings"
        )
        menu_general.addMenu(system_menu)

        menu_general.addSeparator()
        self.close_btn = menu_general.addAction(
            QtGui.QIcon(util.return_icon_path("close.png")), "Close"
        )

        ## TOOLS MENU ##

        menu_tools = menu_bar.addMenu("Tools")
        menu_tools.setTearOffEnabled(True)
        self.followCam = menu_tools.addAction(
            QtGui.QIcon(util.return_icon_path("follow.png")), "Follow Cam"
        )
        self.aimCam = menu_tools.addAction(
            QtGui.QIcon(util.return_icon_path("aim.png")), "Aim Cam"
        )
        menu_tools.addSeparator()
        self.multicams = menu_tools.addAction(
            QtGui.QIcon(util.return_icon_path("camera_multicams.png")), "MultiCams"
        )

        menu_tools.addSeparator()

        self.menu_presets = widgets.OpenMenu("HUD Presets")
        self.menu_presets.setTearOffEnabled(True)
        menu_tools.addMenu(self.menu_presets)
        self.add_presets()
        self.menu_presets.aboutToShow.connect(self.add_presets)

        self.HUD_checkbox = menu_tools.addAction("Display HUDs")
        self.HUD_checkbox.setCheckable(True)
        self.HUD_checkbox.setChecked(self.HUD_display_cam())
        self.HUD_checkbox.triggered.connect(
            lambda state=self.HUD_display_cam(): self.HUD_display_cam(state=state)
        )

        self.version_bar = menu_bar.addMenu(self.VERSION)
        self.version_bar.setEnabled(funcs.check_author())

        latest_action = QtWidgets.QWidgetAction(self)

        self.latest_label = QtWidgets.QLabel()
        self.latest_label.setFixedHeight(util.DPI(32))
        self.latest_label.setContentsMargins(util.DPI(20), 0, util.DPI(20), 0)
        self.latest_label.setStyleSheet(
            "font-size: " + str(util.DPI(14)) + "px; font-weight: bold;"
        )
        latest_action.setDefaultWidget(self.latest_label)
        self.version_bar.addAction(latest_action)

        self.compile_update = self.version_bar.addAction(
            QtGui.QIcon(util.return_icon_path("updates.png")), "Compile Update"
        )
        self.generate_release_notes = self.version_bar.addAction(
            QtGui.QIcon(util.return_icon_path("refresh.png")), "Generate Changes"
        )
        self.version_bar.addSeparator()

        self.open_release_notes = self.version_bar.addAction(
            QtGui.QIcon(util.return_icon_path("load.png")), "Open Release Notes"
        )

        self.version_bar.addSeparator()
        
        self.debug_action = self.version_bar.addAction(
            QtGui.QIcon(util.return_icon_path("debug.png")), "Debug Functions"
        )


        menu_bar.setCornerWidget(self.dock_ui_btn)
        self.main_layout.setMenuBar(menu_bar)

    def debug_function(self):

        cams_widget = omui.MQtUtil.findControl(self.objectName() + "WorkspaceControl")
        cams_ui = util.get_maya_qt(cams_widget, QtWidgets.QWidget)

        topmost_parent = []
        while True:
            parent_widget = cams_ui.parent()
            topmost_parent.append(parent_widget)
            if isinstance(parent_widget, QtWidgets.QMainWindow):
                break
            cams_ui = parent_widget

        for w in topmost_parent:
            print(w)

        if cmds.workspaceControl(self.objectName() + "WorkspaceControl", q=True, floating=True):
            topmost_parent = topmost_parent[-2]
            topmost_parent.resize(self.width(), util.DPI(15))

        else:
            topmost_parent = topmost_parent[2]
            topmost_parent.setSizes([54, topmost_parent.sizes()[1]])

    def create_connections(self):
        self.dock_ui_btn.clicked.connect(self.dock_to_ui)

        self.settings_btn.triggered.connect(self.settings)
        self.reload_btn.triggered.connect(self.reload_cams_UI)
        self.close_btn.triggered.connect(partial(funcs.close_UI, self))

        self.followCam.triggered.connect(partial(funcs.run_tools, "followCam", cams_ui=self))
        self.aimCam.triggered.connect(partial(funcs.run_tools, "aimCam", cams_ui=self))
        self.multicams.triggered.connect(partial(funcs.run_tools, "multicams"))

        self.reset_cams_data.triggered.connect(lambda: self.process_prefs(reset=True))
        self.updates.triggered.connect(partial(funcs.check_for_updates, self))
        self.about.triggered.connect(self.coffee)

        self.version_bar.aboutToShow.connect(self.open_version_bar)
        self.compile_update.triggered.connect(funcs.compile_version)

        self.generate_release_notes.triggered.connect(funcs.changes_compiler)
        
        notes_path = funcs.get_release_notes_path()
        self.open_release_notes.triggered.connect(partial(os.startfile, notes_path))
        
        self.debug_action.triggered.connect(self.debug_function)

    def open_version_bar(self):
        check = funcs.check_author()
        if not check:
            self.version_bar.close()
            self.version_bar.setEnabled(check)
            return

        try:
            version, _, _ = funcs.get_latest_version()
            version = "Old %s" % version if version < self.VERSION else "Up-to-date"
        except:
            version = "Error..."
        self.latest_label.setText(version)

    def set_global_preferences(self):

        self.set_scene_preferences()

        if self.startup_hud:
            pres = self.hud_settings["presets"]
            pref_sel = self.hud_settings["selected"]
            sel = pref_sel if len(pres.keys()) > pref_sel else None
            if sel is not None:
                hud.apply_selection(pres[list(pres.keys())[sel]])

        if not self.skip_update:
            funcs.check_for_updates(self, warning=False)

    def set_scene_preferences(self):

        if self.startup_viewport:
            model_editor_cams = funcs.get_camsDisplay_modeleditor()
            if model_editor_cams:
                for panel, camera in model_editor_cams.items():
                    funcs.look_thru(camera, panel)

        # Set Icons
        for dag in cmds.ls(type="dagContainer"):
            icon_attr = dag + ".iconName"
            if cmds.objExists(icon_attr):
                icon_path = cmds.getAttr(icon_attr)
                if "aleha_tools" in icon_path:
                    cams_type = os.path.basename(icon_path).split(".")[0]
                    cmds.setAttr(
                        icon_attr, util.return_icon_path(cams_type), type="string"
                    )

    def dock_to_ui(self, layout=None, orient=None):
        if not layout:
            layout_name = self.dock_ac_group.checkedAction().text()
            index = list(self.docking_layouts.values()).index(layout_name)
            layout = list(self.docking_layouts.keys())[index]
        if not orient:
            orient_name = self.pos_ac_group.checkedAction().text()
            index = list(self.docking_orients.values()).index(orient_name)
            orient = list(self.docking_orients.keys())[index]

        # Enable / Disable actions
        self.pos_ac_group.checkedAction().setEnabled(False)
        self.dock_ac_group.checkedAction().setEnabled(False)
        for group in [self.pos_ac_group, self.dock_ac_group]:
            for action in group.actions():
                action.setEnabled(not action.isChecked())

        cmds.workspaceControl(
            self.objectName() + "WorkspaceControl",
            e=True,
            dockToControl=[layout, orient],
            tp=["west", 0],
            rsw=util.DPI(200),
            rsh=util.DPI(15),
        )
        self.process_prefs(position=[layout, orient])

    def add_presets(self):
        self.hud_settings = settings.get_pref(
            "hudSettings"
        ) or settings.initial_settings().get("defaultSettings", None)

        self.menu_presets.clear()

        presets_ac_group = QtWidgets.QActionGroup(self)
        if self.hud_settings:
            self.menu_presets.addSeparator().setText("Presets")

            if not self.hud_settings.get("presets", None):
                self.hud_presets = self.hud_settings
                self.hud_settings = {}
                self.hud_settings["presets"] = self.hud_presets
            if type(self.hud_settings.get("selected", None)) != int:
                self.hud_settings["selected"] = 0

            hud_presets = self.hud_settings["presets"]
            selected = self.hud_settings["selected"]

            for ind, p in enumerate(hud_presets):
                preset = QtWidgets.QAction(p, self)
                preset.setCheckable(True)
                presets_ac_group.addAction(preset)
                self.menu_presets.addAction(preset)
                if ind == selected:
                    preset.setChecked(True)
                preset.triggered.connect(
                    partial(self.hud_preset_triggered, ind, hud_presets[p])
                )

        self.menu_presets.addSeparator()

        self.hud_editor = self.menu_presets.addAction("HUD Editor")
        self.hud_editor.triggered.connect(partial(funcs.run_tools, "HUDWindow"))

    def hud_preset_triggered(self, hud_index, preset):
        self.hud_settings["selected"] = hud_index
        settings.save_to_disk("hudSettings", self.hud_settings)
        hud.apply_selection(preset)

    def HUD_display_cam(self, state=None):
        if state is None:
            return cmds.headsUpDisplay(q=True, layoutVisibility=1)
        cmds.headsUpDisplay(e=True, layoutVisibility=state)

    def process_prefs(
        self,
        cam=None,
        near=None,
        far=None,
        overscan=None,
        mask_op=None,
        mask_color=None,
        position=None,
        startup_hud=None,
        startup_viewport=None,
        skip_update=None,
        save=True,
        reset=False,
    ):
        _initial_settings = settings.initial_settings()

        self.cams_prefs = self.user_prefs.get(
            "defaultCameraSettings", None
        ) or _initial_settings.get("defaultCameraSettings", None)
        self.startup_prefs = self.user_prefs.get(
            "startupSettings", {}
        ) or _initial_settings.get("startupSettings", {})

        # Set the value of the attribute to a dictionary of multiple variable values
        if cam:
            if cam != self.cams_prefs["camera"]:
                self.clearLayout(self.default_cam_layout)
                self.default_cam_btn = widgets.HoverButton(cam[0], self)
                self.default_cam_layout.addWidget(self.default_cam_btn)
                self.default_cam_btn.dropped.connect(
                    partial(funcs.drag_insert_camera, cam[0], self)
                )
            self.cams_prefs["camera"] = cam
        if near:
            self.cams_prefs["near_clip"] = near
        if far:
            self.cams_prefs["far_clip"] = far
        if overscan:
            self.cams_prefs["overscan"] = overscan
        if mask_op:
            self.cams_prefs["mask_opacity"] = mask_op
        if mask_color:
            self.cams_prefs["mask_color"] = mask_color

        if position:
            self.startup_prefs["position"] = position
        if startup_hud is not None:
            self.startup_prefs["startup_hud"] = startup_hud
        if startup_viewport is not None:
            self.startup_prefs["startup_viewport"] = startup_viewport
        if skip_update is not None:
            self.startup_prefs["skip_update"] = skip_update

        self.default_cam = (
            self.cams_prefs.get("camera", None)
            or _initial_settings["defaultCameraSettings"]["camera"]
        )

        self.default_overscan = (
            self.cams_prefs.get("overscan", None)
            or _initial_settings["defaultCameraSettings"]["overscan"]
        )

        self.default_near_clip_plane = (
            self.cams_prefs.get("near_clip", None)
            or _initial_settings["defaultCameraSettings"]["near_clip"]
        )

        self.default_far_clip_plane = (
            self.cams_prefs.get("far_clip", None)
            or _initial_settings["defaultCameraSettings"]["far_clip"]
        )

        self.default_resolution = (
            self.cams_prefs.get("display_resolution", None)
            or _initial_settings["defaultCameraSettings"]["display_resolution"]
        )

        self.default_gate_mask_opacity = (
            self.cams_prefs.get("mask_opacity", None)
            or _initial_settings["defaultCameraSettings"]["mask_opacity"]
        )

        self.default_gate_mask_color = (
            self.cams_prefs.get("mask_color", None)
            or _initial_settings["defaultCameraSettings"]["mask_color"]
        )

        self.position = (
            self.startup_prefs.get("position", None)
            if isinstance(self.startup_prefs, dict)
            else _initial_settings["startupSettings"]["position"]
        )

        self.startup_hud = (
            self.startup_prefs.get("startup_hud", None)
            if isinstance(self.startup_prefs, dict)
            else _initial_settings["startupSettings"]["startup_hud"]
        )

        self.startup_viewport = (
            self.startup_prefs.get("startup_viewport", None)
            if isinstance(self.startup_prefs, dict)
            else _initial_settings["startupSettings"]["startup_viewport"]
        )

        self.skip_update = (
            self.startup_prefs.get("skip_update", None)
            if isinstance(self.startup_prefs, dict)
            else _initial_settings["startupSettings"]["skip_update"]
        )

        if save:
            if not reset:
                settings.save_to_disk("defaultCameraSettings", self.cams_prefs)
                settings.save_to_disk("startupSettings", self.startup_prefs)
            else:
                box = QtWidgets.QMessageBox()
                box.setIcon(QtWidgets.QMessageBox.Warning)
                box.setWindowTitle("About to erase All Settings!")
                box.setText(
                    "Are you sure you want to delete all the settings in Default Attributes?\nThis action is NOT undoable."
                )
                box.setStandardButtons(
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                )

                reset = box.button(QtWidgets.QMessageBox.Yes)
                reset.setText("Reset")
                cancel = box.button(QtWidgets.QMessageBox.No)
                cancel.setText("Cancel")
                box.exec_()

                if box.clickedButton() == reset:
                    settings.save_to_disk()

    def settings(self):
        self.process_prefs(save=False)
        try:
            self.settings_window.close()
            self.settings_window.deleteLater()
            self.settings_window = None
        except:
            pass

        self.settings_window = widgets.DefaultSettings
        self.settings_window.show_dialog(self)

    def apply_camera_default(self, cam, button=None):
        parameters = {
            "overscan": self.default_overscan,
            "ncp": self.default_near_clip_plane,
            "fcp": self.default_far_clip_plane,
            "displayResolution": self.default_resolution,
            "displayGateMaskOpacity": self.default_gate_mask_opacity,
            "displayGateMaskColor": self.default_gate_mask_color,
        }

        for i, v in parameters.items():
            try:
                if i == "displayResolution":
                    if v[1]:
                        cmds.setAttr(cam + "." + i, v[0])
                        cmds.setAttr(cam + ".displayGateMask", v[0])
                        if button:
                            button.resolution_checkbox.setChecked(v[0])
                elif i == "displayGateMaskColor":
                    if v[1]:
                        r, g, b = v[0]
                        cmds.setAttr(cam + "." + i, r, g, b, type="double3")
                else:
                    if v[1]:
                        cmds.setAttr(cam + "." + i, v[0])
            except:
                pass

    def clearLayout(self, layout):
        if layout is not None:
            while layout.count():
                item = layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()
                elif isinstance(item, QtWidgets.QLayout):
                    self.clearLayout(item)
                    del item

        try:
            if not util.get_cameras():
                self.line.hide()
            else:
                self.line.show()
        except:
            pass

    def reload_cams_UI(self, *kargs):
        cmds.waitCursor(state=True)
        self.create_buttons()
        if util.get_cameras():
            self.line.show()
        else:
            self.line.hide()
        cmds.waitCursor(state=False)

    """
    Extra Functionality
    """

    def coffee(self):
        coffee_dialog = widgets.Coffee(self.VERSION)
        coffee_dialog.exec_()

    def closeEvent(self, event):
        for no_py_tools in ["MultiCams"]:
            try:
                cmds.deleteUI(no_py_tools)
            except:
                pass
        
        self.remove_callbacks()

        event.accept()

    def eventFilter(self, obj, event):
        if event.type() == QtGui.QKeyEvent.KeyPress:
            current_keys = self._keys_pressed[:]
            for ind, key in enumerate(self.modifier_keys):
                if key == event.key():
                    current_keys[ind] = True
            self.keys_pressed = current_keys

        if event.type() == QtGui.QKeyEvent.KeyRelease:
            current_keys = self._keys_pressed[:]
            for ind, key in enumerate(self.modifier_keys):
                if key == event.key():
                    current_keys[ind] = False
            self.keys_pressed = current_keys

        if util.get_python_version() > 2:
            return super().eventFilter(obj, event)
        else:
            return super(UI, self).eventFilter(obj, event)

    def resizeEvent(self, event):

        cams_widget = omui.MQtUtil.findControl(self.objectName() + "WorkspaceControl")
        cams_ui = util.get_maya_qt(cams_widget, QtWidgets.QWidget)

        if cmds.workspaceControl(self.objectName() + "WorkspaceControl", q=True, floating=True):
            topmost_parent = []
            while True:
                parent_widget = cams_ui.parent()
                topmost_parent.append(parent_widget)
                if isinstance(parent_widget, QtWidgets.QMainWindow):
                    break
                cams_ui = parent_widget
            topmost_parent = topmost_parent[-2]
            current_width = topmost_parent.width()
            new_height = util.DPI(54)
            topmost_parent.resize(current_width, new_height)

        else:
            cams_ui.parent().parent().setFixedHeight(util.DPI(54))

    def camera_deleted_callback(self, obj, *kargs):
        self.reload_cams_UI()

    def camera_creation_callback(self, *kargs):
        sel = cmds.ls(sl=1)
        if sel:
            sel = sel[0]
            print(sel)
            try:
                type = cmds.nodeType(cmds.listRelatives(sel)) or cmds.nodeType(
                    cmds.listRelatives(sel, shapes=True)[0]
                )
            except:
                return
            if type == "camera":
                self.reload_cams_UI()

    def menumode_callback(self, *kargs):
        self.show()
        if cmds.workspaceControl(self.objectName() + "WorkspaceControl", q=True, floating=True):
            cmds.workspaceControl(
                self.objectName() + "WorkspaceControl",
                e=True,
                dockToControl=self.position,
                tp=["west", 0],
                rt=0,
                r=1,
                rsh=util.DPI(15),
                uiScript="import maya.cmds as cmds; cmds.evalDeferred(lambda: cmds.evalDeferred('import aleha_tools.cams as cams; cams.UI().showWindow()', lowestPriority=True))",
            )
        cmds.evalDeferred(self.shelf_tabbar)

    def sceneopened_callback(self, *kargs):
        self.reload_cams_UI()
        self.set_scene_preferences()

    def remove_callbacks(self):
        # Remove callbacks
        for callback_id in self.callback_ids:
            try:
                om.MMessage.removeCallback(callback_id)
            except:
                pass
        self.callback_ids = []


    def add_callbacks(self):
        self.remove_callbacks()

        query_selection = cmds.ls(sl=True)
        # Register callbacks for camera deletion

        cmds.select([cmds.ls(kcam, long=True)[0] for kcam in util.get_cameras()], replace=True)
        sel_list = om.MSelectionList()
        om.MGlobal.getActiveSelectionList(sel_list)

        for i in range(sel_list.length()):
            # Select the camera to get its MObject
            obj = om.MObject()
            sel_list.getDependNode(i, obj)

            # Now you have the MObject for the camera, proceed with your code
            callback_id = om.MNodeMessage.addNodeDestroyedCallback(
                obj, self.camera_deleted_callback, None
            )
            self.callback_ids.append(callback_id)

        cmds.select(query_selection, replace=True)

        # Register callback for camera creation
        self.callback_ids.append(om.MDGMessage.addNodeAddedCallback(
            self.camera_creation_callback)
        )

        # Register callback for menu mode change
        self.callback_ids.append(om.MEventMessage.addEventCallback(
            "MenuModeChanged", self.menumode_callback)
        )

        # Register callback for scene opened
        self.callback_ids.append(om.MSceneMessage.addCallback(
            om.MSceneMessage.kAfterOpen, self.sceneopened_callback)
        )

        # Register callback for scene saved
        self.callback_ids.append(om.MSceneMessage.addCallback(
            om.MSceneMessage.kAfterSave, self.reload_cams_UI)
        )
