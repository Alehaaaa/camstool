from functools import partial
from PySide2 import QtWidgets, QtGui, QtCore
import maya.cmds as cmds
import base64

from .util import *
from .funcs import *


"""
QPainter for the cameras shelf tabBar
"""


class ShelfPainter(QtWidgets.QWidget):
    def paintEvent(self, event):
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        tabbar_width = DPI(16)

        color = self.palette().color(self.backgroundRole())
        painter = QtGui.QPainter(self)
        painter.setPen(QtGui.QPen(color, tabbar_width))
        painter.drawLine(tabbar_width // 2, 0, tabbar_width // 2, self.height())

        line_color = QtGui.QColor(130, 130, 130)
        line_thickness = DPI(1)
        margin = DPI(4)
        center = DPI(5)
        offset = DPI(1.5)

        painter.setPen(QtGui.QPen(line_color, line_thickness, QtCore.Qt.DotLine))

        painter.drawLine(
            QtCore.QPointF(center - offset, margin),
            QtCore.QPointF(center - offset, self.height() - margin),
        )
        painter.drawLine(
            QtCore.QPointF(center + offset, margin),
            QtCore.QPointF(center + offset, self.height() - margin),
        )

    def resizeEvent(self, event):
        self.update()


"""
QMenu that doesn't close
"""


class OpenMenu(QtWidgets.QMenu):
    def __init__(self, parent=None):
        super(OpenMenu, self).__init__(parent)

    def mouseReleaseEvent(self, e):
        action = self.activeAction()
        try:
            if action.isEnabled():
                action.setEnabled(False)
                super(OpenMenu, self).mouseReleaseEvent(e)
                action.setEnabled(True)
                action.trigger()
            else:
                super(OpenMenu, self).mouseReleaseEvent(e)
        except:
            super(OpenMenu, self).mouseReleaseEvent(e)


"""
QPushButton hover detection
"""


class HoverButton(QtWidgets.QPushButton):
    dropped = QtCore.Signal(tuple)

    def __init__(self, camera, ui=None):
        super(HoverButton, self).__init__()
        self.parentUI = ui
        self.camera = camera

        self.setAcceptDrops(True)

        cam_type = "camera"
        type_attr = camera + ".cams_type"
        if cmds.objExists(type_attr):
            cam_type = cmds.getAttr(type_attr)

        if len(camera) > 10:
            _camera = camera[-8:]
            btn_name = ".." + _camera
        else:
            btn_name = camera

        self.setFixedHeight(DPI(25))
        self.setText(btn_name)
        self.setToolTip(camera)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        base_color = getcolor(camera)
        color = ", ".join([str(x) for x in base_color])
        light_color = ", ".join([str(x * 1.2) for x in base_color])
        dark_color = ", ".join([str(x * 0.6) for x in base_color])

        self.button_stylesheet = (
            """
            QPushButton {
                padding-left: """
            + str(DPI(4))
            + """px;
                padding-right: """
            + str(DPI(4))
            + """px;
                color: black;
                background-color: rgb("""
            + color
            + """);
                border-radius:"""
            + str(DPI(5))
            + """px;
            }

            QPushButton:hover {
                background-color:rgb("""
            + light_color
            + """);
            }

            QPushButton:pressed {
                background-color: rgb("""
            + dark_color
            + """);
            }

            QToolTip { 
                background-color: rgb("""
            + light_color
            + """);
            }
        """
        )

        self.setStyleSheet(self.button_stylesheet)

        self.default_icon = QtGui.QIcon(return_icon_path(cam_type + ".png"))

        self.select_icon = QtGui.QIcon(return_icon_path("select.png"))
        self.deselect_icon = QtGui.QIcon(return_icon_path("deselect.png"))
        self.duplicate_icon = QtGui.QIcon(return_icon_path("duplicate.png"))
        self.rename_icon = QtGui.QIcon(return_icon_path("rename.png"))

        self.remove_icon = QtGui.QIcon(return_icon_path("remove.png"))
        self.tearoff_icon = QtGui.QIcon(return_icon_path("tear_off.png"))
        self.attributes_icon = QtGui.QIcon(return_icon_path("attributes.png"))

        self.setIcon(self.default_icon)
        self.setStatusTip("Look thru " + self.camera)

        # Right-click menu for button
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(
            lambda pos, c=self.camera, button=self, cam_type=cam_type: self.show_context_menu(
                pos, c, button, cam_type
            )
        )

        self.installEventFilter(self)

        if self.parentUI:
            # Connect the signal to the slot
            try:
                self.parentUI.keys_pressed_changed.connect(self.on_keys_pressed_changed)
            except:
                pass

    def update_section_sub_elements(self, section, actions, cam_panels, cam, set=True):
        check = section.isChecked()
        # Handler function to update the check states of sub-elements based on the section's check state
        if set:
            commands = []
            for action, command, plugin in actions:
                action.setChecked(check)
                set_cam_display(cam_panels, command, plugin=plugin, switch=check)
                commands.append((command, plugin, check))
            self.save_display_to_cam(cam)

    def set_display_attribute(
        self, cam, action, cam_panels, s_action, actions, command, plugin=False
    ):
        s_action.setChecked(not any(not a[0].isChecked() for a in actions))
        if cam_panels:
            set_cam_display(cam_panels, command, plugin=plugin)
        self.save_display_to_cam(cam, [(command, plugin, action.isChecked())])

    def save_display_to_cam(self, cam, commands=None):
        all_preferences = [(p[1], p[2]) for s in self.show_elements.values() for p in s]
        current_preferences = get_preferences_display(cam)

        if not current_preferences:
            cam_panels = self.get_pane_from_cam(cam)
            for preference in all_preferences:
                pref, plugin = preference
                value = get_cam_display(cam_panels, pref, plugin=plugin)
                current_preferences[pref] = (plugin, value)
        if commands:
            if not isinstance(commands, list):
                commands = [commands]
            for command in commands:
                command, plugin, value = command
                current_preferences[command] = (plugin, value)

        cmds.setAttr(cam + ".cams_display", current_preferences, type="string")

    def get_pane_from_cam(self, cam):
        cam_panels = []
        current_cam = cam
        try:
            current_cam = cmds.listRelatives(current_cam)[0]
        except:
            pass
        for pane in cmds.getPanel(type="modelPanel"):
            pane_cam = cmds.modelPanel(pane, query=True, camera=True)
            if pane_cam:
                try:
                    pane_cam = cmds.listRelatives(pane_cam)[0]
                except:
                    pass
                if pane_cam == current_cam:
                    cam_panels.append(pane)
        return cam_panels

    def show_context_menu(self, pos, cam, button, cam_type="camera"):
        if not cmds.objExists(cam):
            self.parentUI.reload_cams_UI()
            return

        self.context_menu = OpenMenu()

        title_action = QtWidgets.QWidgetAction(self)
        title_label = QtWidgets.QLabel("..." + cam[-17:] if len(cam) > 18 else cam)
        title_label.setFixedHeight(DPI(32))
        title_label.setContentsMargins(DPI(20), 0, DPI(20), 0)
        title_label.setStyleSheet(
            "font-size: " + str(DPI(14)) + "px; font-weight: bold;"
        )
        title_action.setDefaultWidget(title_label)
        self.context_menu.addAction(title_action)

        self.select_btn = self.context_menu.addAction(
            QtGui.QIcon(return_icon_path("select.png")),
            "Select",
            partial(select_cam, cam, self),
        )
        self.deselect_btn = self.context_menu.addAction(
            QtGui.QIcon(return_icon_path("deselect.png")),
            "Deselect",
            partial(deselect_cam, cam, self),
        )

        if cam in cmds.ls(selection=True):
            self.select_btn.setVisible(False)
        else:
            self.deselect_btn.setVisible(False)

        self.context_menu.addAction(
            QtGui.QIcon(return_icon_path("duplicate.png")),
            "Duplicate",
            partial(duplicate_cam, cam, self),
        )
        if cam == self.parentUI.default_cam[0]:
            default_cam_menu = OpenMenu("Main Camera")
            default_cam_menu.setIcon(QtGui.QIcon(return_icon_path("camera.png")))
            default_cam_menu_grp = QtWidgets.QActionGroup(self)

            for c in get_cameras(default=True):
                action = default_cam_menu.addAction(
                    c, partial(self.set_default_cam, (c, True))
                )
                default_cam_menu_grp.addAction(action)
                action.setCheckable(True)
                action.setChecked(c == cam)
            self.context_menu.addMenu(default_cam_menu)

        if cam != self.parentUI.default_cam[0] and not cmds.referenceQuery(
            cam, isNodeReferenced=True
        ):
            self.context_menu.addAction(
                QtGui.QIcon(return_icon_path("rename.png")),
                "Rename",
                partial(rename_cam, cam, self.parentUI),
            )

        self.context_menu.addSeparator()

        self.menu_show = OpenMenu("Viewport Show")
        self.menu_show.setTearOffEnabled(True)
        cam_panels = self.get_pane_from_cam(cam)
        visible_planels = bool(cam_panels)

        # Mark the ones that are plugins
        self.show_elements = {
            "Curves": (
                ("NURBS Curves", "nurbsCurves", 0),
                ("NURBS Surfaces", "nurbsSurfaces", 0),
            ),
            "Surfaces": (
                ("Polygons", "polymeshes", 0),
                ("Textures", "displayTextures", 0),
            ),
            "Visualising": (
                ("Cameras", "cameras", 0),
                ("Hold-Outs", "holdOuts", 0),
                ("Image Planes", "imagePlane", 0),
                ("Motion Trails", "motionTrails", 0),
            ),
            "Rigging": (
                ("Locators", "locators", 0),
                ("IK Handles", "ikHandles", 0),
                ("Joints", "joints", 0),
                ("Deformers", "deformers", 0),
            ),
            "Viewport Utilities": (
                ("Grid", "grid", 0),
                ("Manipulators", "manipulators", 0),
                ("Selection Highlight", "selectionHiliteDisplay", 0),
            ),
            "Plugins": (
                ("GPU Cache", "gpuCacheDisplayFilter", 1),
                ("Blue Pencil", "bluePencil", 0),
            ),
        }
        preferences = get_preferences_display(cam)

        for section in list(self.show_elements.keys()):
            self.menu_show.addSeparator()
            s_action = self.menu_show.addAction(section)
            s_action.setCheckable(True)

            actions = []
            for el in self.show_elements[section]:
                pretty, command, plugin = el

                el_action = self.menu_show.addAction("     " + pretty)
                el_action.setCheckable(True)
                actions.append((el_action, command, plugin))

            for action, command, plugin in actions:
                action.triggered.connect(
                    partial(
                        self.set_display_attribute,
                        cam,
                        action,
                        cam_panels,
                        s_action,
                        actions,
                        command,
                        plugin=plugin,
                    )
                )
                if visible_planels:
                    action.setChecked(
                        get_cam_display(cam_panels, command, plugin=plugin)
                    )

                elif preferences:
                    action.setChecked(preferences.get(command, ["", 0])[1])

            s_action.setChecked(all(e.isChecked() for e in [a[0] for a in actions]))
            s_action.triggered.connect(
                partial(
                    self.update_section_sub_elements, s_action, actions, cam_panels, cam
                )
            )

        self.context_menu.addMenu(self.menu_show)

        if cam_type == "camera_aim":
            offset_attr = cam + ".cams_aim_offset"
            if cmds.objExists(offset_attr):
                self.context_menu.addAction(
                    QtGui.QIcon(return_icon_path("aim.png")),
                    "Position Aim",
                    partial(self.position_aim_offset, offset_attr),
                )

        elif cam_type == "camera_follow":
            const_attr = cam + ".cams_follow_attr"
            if cmds.objExists(const_attr):

                const_switch_attr = cmds.getAttr(const_attr)
                const_switch = cmds.getAttr(const_switch_attr)

                follow_consts_menu = OpenMenu("Follow Mode")
                follow_consts_action_grp = QtWidgets.QActionGroup(self)
                follow_consts_menu.setIcon(QtGui.QIcon(return_icon_path("follow.png")))

                self.parent_const_btn = follow_consts_menu.addAction(
                    "Position, Rotation"
                )
                follow_consts_action_grp.addAction(self.parent_const_btn)
                self.parent_const_btn.setCheckable(True)
                self.parent_const_btn.setChecked(const_switch)

                self.point_const_btn = follow_consts_menu.addAction("Only Position")
                follow_consts_action_grp.addAction(self.point_const_btn)
                self.point_const_btn.setCheckable(True)
                self.point_const_btn.setChecked(not const_switch)

                self.point_const_btn.triggered.connect(
                    partial(cmds.setAttr, const_switch_attr, False)
                )
                self.parent_const_btn.triggered.connect(
                    partial(cmds.setAttr, const_switch_attr, True)
                )

                self.context_menu.addMenu(follow_consts_menu)

        self.context_menu.addSeparator()

        self.resolution_checkbox = self.context_menu.addAction(
            "Display Gate", partial(self.resolution_cam, cam)
        )
        self.resolution_checkbox.setCheckable(True)
        self.resolution_checkbox.setChecked(cmds.getAttr(cam + ".displayResolution"))

        self.context_menu.addAction(
            QtGui.QIcon(return_icon_path("attributes.png")),
            "Attributes",
            partial(Attributes.show_dialog, cam, self.window()),
        )

        self.context_menu.addAction(
            QtGui.QIcon(return_icon_path("default.png")),
            "Apply Defaults",
            partial(self.parentUI.apply_camera_default, cam, self),
        )
        self.context_menu.addSeparator()

        self.context_menu.addAction(
            QtGui.QIcon(return_icon_path("tear_off.png")),
            "Tear Off Copy",
            partial(tear_off_cam, cam),
        )

        if cam != self.parentUI.default_cam[0] and not cmds.referenceQuery(
            cam, isNodeReferenced=True
        ):
            self.context_menu.addSeparator()
            self.context_menu.addAction(
                QtGui.QIcon(return_icon_path("remove.png")),
                "Delete",
                partial(delete_cam, cam, self.parentUI),
            )

        self.context_menu.exec_(button.mapToGlobal(pos))

    def position_aim_offset(self, offset_attr):
        cmds.select(cmds.getAttr(offset_attr))
        cmds.setToolTo("moveSuperContext")
        self.context_menu.close()

    def resolution_cam(self, cam):
        cmds.setAttr(cam + ".displayGateMask", self.resolution_checkbox.isChecked())
        cmds.setAttr(cam + ".displayResolution", self.resolution_checkbox.isChecked())

    def set_default_cam(self, cam):
        self.parentUI.process_prefs(cam=cam)
        self.context_menu.close()

    def on_keys_pressed_changed(self):
        if self.underMouse():
            parent_keys = self.parentUI.keys_pressed
            control_pressed, shift_pressed, alt_pressed = parent_keys
            try:
                self.clicked.disconnect()
            except:
                pass

            if shift_pressed and not control_pressed and not alt_pressed:
                self.setIcon(self.select_icon)
                self.clicked.connect(partial(select_cam, self.camera))
                self.setStatusTip("Add " + self.camera + " to selection")

            elif control_pressed and not shift_pressed and not alt_pressed:
                self.setIcon(self.deselect_icon)
                self.clicked.connect(partial(deselect_cam, self.camera))
                self.setStatusTip("Remove " + self.camera + " from selection")

            elif control_pressed and shift_pressed and not alt_pressed:
                self.setIcon(self.duplicate_icon)
                self.clicked.connect(partial(duplicate_cam, self.camera, self))
                self.setStatusTip("Duplicate " + self.camera)

            elif control_pressed and alt_pressed and not shift_pressed:
                self.setIcon(self.rename_icon)
                self.clicked.connect(partial(rename_cam, self.camera, self.parentUI))
                self.setStatusTip("Rename " + self.camera)

            elif control_pressed and alt_pressed and shift_pressed:
                self.setIcon(self.remove_icon)
                self.clicked.connect(partial(delete_cam, self.camera, self.parentUI))
                self.setStatusTip("Delete " + self.camera)

            elif alt_pressed and shift_pressed and not control_pressed:
                self.setIcon(self.tearoff_icon)
                self.clicked.connect(partial(tear_off_cam, self.camera))
                self.setStatusTip("Tear Off " + self.camera)

            elif alt_pressed and not control_pressed and not shift_pressed:
                self.setIcon(self.attributes_icon)
                self.clicked.connect(
                    partial(Attributes.show_dialog, self.camera, self.window())
                )
                self.setStatusTip("Attributes of " + self.camera)

            else:
                self.setIcon(self.default_icon)
                self.clicked.connect(
                    partial(look_thru, cam=self.camera, ui=self.parentUI)
                )
                self.setStatusTip("Look thru " + self.camera)

    def mouseMoveEvent(self, e):
        if e.buttons() != QtCore.Qt.LeftButton:
            return

        # Start drag operation
        drag = QtGui.QDrag(self)
        mime_data = QtCore.QMimeData()
        drag.setMimeData(mime_data)

        # Set the pixmap
        pixmap = self.grab()
        drag.setPixmap(pixmap)
        # shift the Pixmap so that it coincides with the cursor position
        drag.setHotSpot(e.pos())

        # Execute the drag operation
        drag.exec_(QtCore.Qt.CopyAction)

        # Emit the dropped signal when the drag operation is completed
        cursor_pos = QtGui.QCursor.pos()  # Get the global cursor position
        xy_pos = (cursor_pos.x(), cursor_pos.y())
        self.dropped.emit(xy_pos)

    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.Enter:
            self.on_keys_pressed_changed()

        if event.type() == QtCore.QEvent.Leave:
            self.setIcon(self.default_icon)
            self.setDown(False)

        if get_python_version() == 2:
            return super(HoverButton, self).eventFilter(obj, event)
        elif get_python_version() == 3:
            return super().eventFilter(obj, event)


"""
QScroll for the cameras layout
"""


class HorizontalScrollArea(QtWidgets.QScrollArea):
    def __init__(self, height, parent=None):
        super(HorizontalScrollArea, self).__init__(parent)

        self.setFrameStyle(QtWidgets.QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setWidgetResizable(True)
        self.setFixedHeight(height)

        # Create a container widget for the content
        self.container_widget = QtWidgets.QWidget(self)
        self.container_layout = QtWidgets.QHBoxLayout(self.container_widget)
        self.container_layout.setContentsMargins(0, 0, 0, 0)
        self.container_layout.setSpacing(DPI(5))

        # Set the container widget as the scroll area's widget
        self.setWidget(self.container_widget)

    def wheelEvent(self, event):
        if event.type() == QtGui.QWheelEvent.Wheel:
            delta = event.angleDelta().y() / 120  # Normalizing delta
            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - (delta * 30)
            )
            event.accept()
        super(HorizontalScrollArea, self).wheelEvent(event)


"""
Attributes
"""


class Attributes(QtWidgets.QDialog):
    dlg_instance = None

    @classmethod
    def show_dialog(cls, cams, parent):
        try:
            cls.dlg_instance.close()
            cls.dlg_instance.deleteLater()
        except:
            pass

        cls.dlg_instance = Attributes(cams, parent)
        cls.dlg_instance.show()

    def __init__(self, cam, parent=None):
        super(Attributes, self).__init__(parent)

        self.cam = cam

        self.setWindowTitle("Attributes: " + self.cam)
        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)

        # First section: Attributes
        self.onlyFloat = QtGui.QDoubleValidator(self)

        self.create_layouts()
        self.create_widgets()
        self.create_connections()

        self.setFixedSize(self.sizeHint().width(), self.sizeHint().height())

    def create_layouts(self):
        self.form_layout = QtWidgets.QFormLayout(self)
        self.form_layout.setVerticalSpacing(DPI(10))
        self.focal_length_container = QtWidgets.QHBoxLayout()
        self.near_clip_plane_container = QtWidgets.QHBoxLayout()
        self.far_clip_plane_container = QtWidgets.QHBoxLayout()
        self.overscan_container = QtWidgets.QHBoxLayout()
        self.opacity_container = QtWidgets.QHBoxLayout()
        self.color_slider_and_picker = QtWidgets.QHBoxLayout()
        self.apply_buttons = QtWidgets.QHBoxLayout()

    def create_widgets(self):
        self.focal_length_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.focal_length_slider.setRange(2500, 500000)
        self.focal_length_slider.setValue(
            int(round(cmds.getAttr(self.cam + ".fl") * 1000))
        )

        self.focal_length_value = QtWidgets.QLineEdit()
        self.focal_length_value.setText(
            str(self.get_float(self.focal_length_slider.value()))
        )
        self.focal_length_value.setFixedWidth(DPI(80))

        self.overscan_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.overscan_slider.setRange(1000, 2000)
        self.overscan_slider.setValue(int(cmds.getAttr(self.cam + ".overscan") * 1000))

        self.overscan_value = QtWidgets.QLineEdit()
        self.overscan_value.setText(str(self.get_float(self.overscan_slider.value())))
        self.overscan_value.setFixedWidth(DPI(80))

        self.near_clip_plane = QtWidgets.QLineEdit()
        self.far_clip_plane = QtWidgets.QLineEdit()
        self.near_clip_plane.setFixedWidth(DPI(80))
        self.far_clip_plane.setFixedWidth(DPI(80))

        self.focal_length_value.setValidator(self.onlyFloat)
        self.overscan_value.setValidator(self.onlyFloat)
        self.near_clip_plane.setValidator(self.onlyFloat)
        self.far_clip_plane.setValidator(self.onlyFloat)

        self.near_clip_plane.setText(str(cmds.getAttr(self.cam + ".ncp")))
        self.far_clip_plane.setText(str(cmds.getAttr(self.cam + ".fcp")))

        self.near_clip_lock = self.create_lock_button()
        self.near_clip_lock.setVisible(False)
        self.near_clip_plane_container.addWidget(self.near_clip_plane)
        self.near_clip_plane_container.addStretch()
        self.near_clip_plane_container.addWidget(self.near_clip_lock)

        self.far_clip_lock = self.create_lock_button()
        self.far_clip_lock.setVisible(False)
        self.far_clip_plane_container.addWidget(self.far_clip_plane)
        self.far_clip_plane_container.addStretch()
        self.far_clip_plane_container.addWidget(self.far_clip_lock)

        self.focal_length_lock = self.create_lock_button()
        self.focal_length_lock.setVisible(False)
        self.focal_length_container.addWidget(self.focal_length_value)
        self.focal_length_container.addWidget(self.focal_length_slider)
        self.focal_length_container.addStretch()
        self.focal_length_container.addWidget(self.focal_length_lock)

        self.overscan_lock = self.create_lock_button()
        self.overscan_lock.setVisible(False)
        self.overscan_container.addWidget(self.overscan_value)
        self.overscan_container.addWidget(self.overscan_slider)
        self.overscan_container.addStretch()
        self.overscan_container.addWidget(self.overscan_lock)

        # Second section: Display Attributes
        self.gate_mask_opacity_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.gate_mask_opacity_slider.setRange(0, 1000)
        self.gate_mask_opacity_slider.setValue(
            int(round(cmds.getAttr(self.cam + ".displayGateMaskOpacity") * 1000))
        )
        self.gate_mask_opacity_value = QtWidgets.QLineEdit()
        self.gate_mask_opacity_value.setText(
            str(self.get_float(self.gate_mask_opacity_slider.value()))
        )
        self.gate_mask_opacity_value.setFixedWidth(DPI(80))

        self.opacity_lock = self.create_lock_button()
        self.opacity_lock.setVisible(False)
        self.opacity_container.addWidget(self.gate_mask_opacity_value)
        self.opacity_container.addWidget(self.gate_mask_opacity_slider)
        self.opacity_container.addStretch()
        self.opacity_container.addWidget(self.opacity_lock)

        self.gate_mask_color_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.gate_mask_color_slider.setRange(0, 255)
        self.gate_mask_color_slider.setValue(128)
        self.gate_mask_color_picker = QtWidgets.QPushButton()
        self.gate_mask_color_picker.setFixedWidth(DPI(80))
        self.gate_mask_color_picker.setFixedHeight(DPI(17))

        self.update_button_color(self.cam)

        self.color_lock = self.create_lock_button()
        self.color_lock.setVisible(False)
        self.color_slider_and_picker.addWidget(self.gate_mask_color_picker)
        self.color_slider_and_picker.addWidget(self.gate_mask_color_slider)
        self.color_slider_and_picker.addStretch()
        self.color_slider_and_picker.addWidget(self.color_lock)

        self.ok_btn = QtWidgets.QPushButton("OK")
        self.apply_btn = QtWidgets.QPushButton("Apply")
        self.cancel_btn = QtWidgets.QPushButton("Cancel")

        self.apply_buttons.addWidget(self.ok_btn)
        self.apply_buttons.addWidget(self.apply_btn)
        self.apply_buttons.addWidget(self.cancel_btn)

        self.form_layout.addRow("Focal Length:", self.focal_length_container)
        self.form_layout.addRow(QtWidgets.QFrame(frameShape=QtWidgets.QFrame.HLine))
        self.form_layout.addRow("Near Clip Plane:", self.near_clip_plane_container)
        self.form_layout.addRow("Far Clip Plane:", self.far_clip_plane_container)
        self.form_layout.addRow(QtWidgets.QFrame(frameShape=QtWidgets.QFrame.HLine))
        self.form_layout.addRow("Overscan:", self.overscan_container)
        self.form_layout.addRow("Gate Mask Opacity:", self.opacity_container)
        self.form_layout.addRow("Gate Mask Color:", self.color_slider_and_picker)

        self.form_layout.addRow(self.apply_buttons)

        self.all_widgets = [
            {
                "target": [self.focal_length_value, self.focal_length_slider],
                "attr": ".fl",
                "lock": self.focal_length_lock,
            },
            {
                "target": [self.overscan_value, self.overscan_slider],
                "attr": ".overscan",
                "lock": self.overscan_lock,
            },
            {
                "target": [self.near_clip_plane],
                "attr": ".ncp",
                "lock": self.near_clip_lock,
            },
            {
                "target": [self.far_clip_plane],
                "attr": ".fcp",
                "lock": self.far_clip_lock,
            },
            {
                "target": [self.gate_mask_opacity_value, self.gate_mask_color_slider],
                "attr": ".displayGateMaskOpacity",
                "lock": self.opacity_lock,
            },
            {
                "target": [self.gate_mask_color_picker, self.gate_mask_opacity_slider],
                "attr": ".displayGateMaskColor",
                "lock": self.color_lock,
            },
        ]

    def create_connections(self):

        for widget in self.all_widgets:
            attr = self.cam + widget.get("attr", "")
            targets = widget.get("target", [])
            lock_btn = widget.get("lock", "")

            settable = True

            if not cmds.getAttr(attr, settable=True):
                settable = False
                lock_btn.setVisible(True)
                lock_btn.clicked.connect(
                    partial(self.disconnect_locked_attr, attr, targets, lock_btn)
                )

            for target in targets:
                value = cmds.getAttr(attr)
                if isinstance(target, QtWidgets.QLineEdit):
                    target.setText(str(str(self.get_float(value * 1000))))
                    target.returnPressed.connect(
                        partial(self.apply_modifications, self.cam, close=True)
                    )
                elif isinstance(target, QtWidgets.QSlider) and type(value) != list:
                    target.setValue(int(round(value * 1000)))

                target.setEnabled(settable)

        self.ok_btn.clicked.connect(
            partial(self.apply_modifications, self.cam, close=True)
        )
        self.apply_btn.clicked.connect(partial(self.apply_modifications, self.cam))
        self.cancel_btn.clicked.connect(self.close)

        self.focal_length_slider.valueChanged.connect(
            lambda: self.focal_length_value.setText(
                str(self.get_float(self.focal_length_slider.value()))
            )
        )

        self.overscan_slider.valueChanged.connect(
            lambda: self.overscan_value.setText(
                str(self.get_float(self.overscan_slider.value()))
            )
        )

        self.gate_mask_opacity_slider.valueChanged.connect(
            lambda: self.gate_mask_opacity_value.setText(
                self.get_float(self.gate_mask_opacity_slider.value())
            )
        )

        self.gate_mask_color_picker.clicked.connect(
            lambda: self.show_color_selector(self.gate_mask_color_picker)
        )

        self.gate_mask_color_slider.valueChanged.connect(
            lambda: self.update_button_value(self.gate_mask_color_slider.value())
        )

    def create_lock_button(self):
        lock_btn = QtWidgets.QPushButton()
        lock_btn.setToolTip("Break connection")
        lock_btn.setStatusTip("Break connection")

        lock_btn.setIcon(QtGui.QIcon(return_icon_path("locked.png")))
        lock_btn.setFixedSize(DPI(15), DPI(15))

        return lock_btn

    def disconnect_locked_attr(self, attr, targets, lock_btn):
        res = QtWidgets.QMessageBox.question(
            None,
            "Break connection",
            "Are you sure you want to break the connection to\n'" + attr + "'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No,
        )
        if res != QtWidgets.QMessageBox.Yes:
            return
        connections = cmds.listConnections(attr, plugs=True)
        if connections:
            cmds.disconnectAttr(connections[0], attr)

        for target in targets:
            target.setEnabled(True)

        lock_btn.setVisible(False)

    """
    Create functions
    """

    def apply_modifications(self, cam, close=False):
        cmds.undoInfo(chunkName="applyCamAttributes", openChunk=True)
        try:
            self.get_picker_color()
            parameters = {
                "fl": self.focal_length_value.text(),
                "overscan": self.overscan_value.text(),
                "ncp": self.near_clip_plane.text(),
                "fcp": self.far_clip_plane.text(),
                "displayGateMaskOpacity": self.gate_mask_opacity_value.text(),
                "displayGateMaskColor": self.gate_mask_color_rgbf,
            }

            for i, v in parameters.items():
                attr = cam + "." + i
                if cmds.getAttr(attr, settable=True):
                    if v:
                        if type(v) != list:
                            cmds.setAttr(attr, float(v))
                        else:
                            r, g, b = v
                            cmds.setAttr(attr, r, g, b, type="double3")

            if close:
                self.close()
        finally:
            cmds.undoInfo(closeChunk=True)

    def get_float(self, value):
        return "%.3f" % (value / 1000.0)

    def get_picker_color(self):
        style_sheet = self.gate_mask_color_picker.styleSheet()
        bg_color = style_sheet[style_sheet.find(":") + 1 :].strip()
        qcolor = QtGui.QColor(bg_color)
        r, g, b, _ = qcolor.getRgbF()
        self.gate_mask_color_rgbf = [r, g, b]

    def update_button_color(self, cam):
        rgb = cmds.getAttr(cam + ".displayGateMaskColor")[0]
        qcolor = QtGui.QColor(*[int(q * 255) for q in rgb])
        h, s, v, _ = qcolor.getHsv()
        qcolor.setHsv(h, s, v)
        self.gate_mask_color_picker.setStyleSheet("background-color: " + qcolor.name())
        self.gate_mask_color_slider.setValue(v)

    def update_button_value(self, value):
        color = self.gate_mask_color_picker.palette().color(QtGui.QPalette.Button)
        h, s, v, _ = color.getHsv()
        color.setHsv(h, s, value)
        self.gate_mask_color_picker.setStyleSheet("background-color: " + color.name())

    def show_color_selector(self, button):
        initial_color = button.palette().color(QtGui.QPalette.Base)
        color = QtWidgets.QColorDialog.getColor(initial=initial_color)
        if color.isValid():
            button.setStyleSheet("background-color: " + color.name())
            h, s, v, _ = color.getHsv()
            self.gate_mask_color_slider.setValue(v)


"""
Default Settings
"""


class DefaultSettings(QtWidgets.QDialog):
    dlg_instance = None

    @classmethod
    def show_dialog(cls, parent):
        try:
            cls.dlg_instance.close()
            cls.dlg_instance.deleteLater()
        except:
            pass

        cls.dlg_instance = DefaultSettings(parent)
        cls.dlg_instance.show()

    def __init__(self, parent=None):
        super(DefaultSettings, self).__init__(parent)

        self.parentUI = parent

        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)
        self.setWindowTitle("Default Attributes")

        self.create_layouts()
        self.create_widgets()
        self.create_connections()

        self.setFixedSize(DPI(320), self.sizeHint().height())

    def create_layouts(self):
        self.main_layout = QtWidgets.QFormLayout()
        self.main_layout.setVerticalSpacing(DPI(10))
        self.setLayout(self.main_layout)

    def create_widgets(self):
        onlyFloat = QtGui.QRegExpValidator(QtCore.QRegExp(r"[0-9].+"))

        description_label = QtWidgets.QLabel(
            "Mark the default attributes you want to be saved."
        )
        description_label.setAlignment(QtCore.Qt.AlignCenter)

        self.near_clip_plane = QtWidgets.QLineEdit()
        self.far_clip_plane = QtWidgets.QLineEdit()
        self.near_clip_plane.setText(str(self.parentUI.default_near_clip_plane[0]))
        self.far_clip_plane.setText(str(self.parentUI.default_far_clip_plane[0]))

        self.near_clip_plane.setEnabled(self.parentUI.default_near_clip_plane[1])
        self.far_clip_plane.setEnabled(self.parentUI.default_far_clip_plane[1])

        self.overscan_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.overscan_value = QtWidgets.QLineEdit()
        self.overscan_slider.setRange(1000, 2000)
        self.overscan_slider.setValue((float(self.parentUI.default_overscan[0]) * 1000))
        self.overscan_value.setText(str(self.get_float(self.overscan_slider.value())))

        self.overscan_slider.setEnabled(self.parentUI.default_overscan[1])
        self.overscan_value.setEnabled(self.parentUI.default_overscan[1])

        self.gate_mask_opacity_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.gate_mask_opacity_slider.setRange(0, 1000)
        self.gate_mask_opacity_slider.setValue(
            int(float(self.parentUI.default_gate_mask_opacity[0]) * 1000)
        )

        self.gate_mask_opacity_value = QtWidgets.QLineEdit()
        self.gate_mask_opacity_value.setText(
            str(self.get_float(self.gate_mask_opacity_slider.value()))
        )

        self.gate_mask_opacity_slider.setEnabled(
            self.parentUI.default_gate_mask_opacity[1]
        )
        self.gate_mask_opacity_value.setEnabled(
            self.parentUI.default_gate_mask_opacity[1]
        )

        overscan_container = QtWidgets.QHBoxLayout()
        overscan_container.addWidget(self.overscan_value)
        overscan_container.addWidget(self.overscan_slider)

        gate_mask_opacity_container = QtWidgets.QHBoxLayout()
        gate_mask_opacity_container.addWidget(self.gate_mask_opacity_value)
        gate_mask_opacity_container.addWidget(self.gate_mask_opacity_slider)

        color_slider_and_picker = QtWidgets.QHBoxLayout()
        self.gate_mask_color_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.gate_mask_color_slider.setRange(0, 255)
        self.gate_mask_color_slider.setValue(128)
        self.gate_mask_color_picker = QtWidgets.QPushButton()
        self.gate_mask_color_picker.setFixedWidth(DPI(80))
        self.gate_mask_color_picker.setFixedHeight(DPI(17))

        self.gate_mask_color_picker.setEnabled(self.parentUI.default_gate_mask_color[1])
        self.gate_mask_color_slider.setEnabled(self.parentUI.default_gate_mask_color[1])

        self.update_button_color()

        color_slider_and_picker.addWidget(self.gate_mask_color_picker)
        color_slider_and_picker.addWidget(self.gate_mask_color_slider)

        self.near_clip_plane.setValidator(onlyFloat)
        self.far_clip_plane.setValidator(onlyFloat)
        self.overscan_value.setValidator(onlyFloat)
        self.gate_mask_opacity_value.setValidator(onlyFloat)

        self.near_clip_plane.setFixedWidth(DPI(80))
        self.far_clip_plane.setFixedWidth(DPI(80))
        self.overscan_value.setFixedWidth(DPI(80))
        self.gate_mask_opacity_value.setFixedWidth(DPI(80))

        ok_close_layout = QtWidgets.QHBoxLayout()
        self.ok_btn = QtWidgets.QPushButton("OK")
        self.close_btn = QtWidgets.QPushButton("Close")
        ok_close_layout.addWidget(self.ok_btn)
        ok_close_layout.addWidget(self.close_btn)

        from collections import OrderedDict

        layout_dict = {
            "Near Clip Plane": self.near_clip_plane,
            "Far Clip Plane": self.far_clip_plane,
            "Overscan": overscan_container,
            "Gate Mask Opacity": gate_mask_opacity_container,
            "Gate Mask Color": color_slider_and_picker,
        }

        self.main_layout.addRow(description_label)
        self.main_layout.addRow(QtWidgets.QFrame(frameShape=QtWidgets.QFrame.HLine))
        # Loop through each key-value pair in the dictionary and add it to the layout with a checkbox
        for index, (key, value) in enumerate(layout_dict.items()):
            if index == 2:
                self.main_layout.addRow(
                    QtWidgets.QFrame(frameShape=QtWidgets.QFrame.HLine)
                )

            widget_container = QtWidgets.QHBoxLayout()
            widget_container.setSpacing(DPI(5))
            checkbox = QtWidgets.QCheckBox()
            checkbox.setFixedWidth(DPI(15))
            widget_container.addWidget(checkbox)
            label = QtWidgets.QLabel(key)
            label.setFixedWidth(DPI(100))
            widget_container.addWidget(label)
            if isinstance(value, QtWidgets.QLayout):
                for i in range(value.count()):
                    widget = value.itemAt(i).widget()
                    if isinstance(widget, QtWidgets.QWidget):
                        checkbox.setChecked(widget.isEnabled())
                        checkbox.toggled.connect(
                            lambda checked=checkbox.isChecked(), v=widget: v.setEnabled(
                                checked
                            )
                        )
                widget_container.addLayout(value)
            if isinstance(value, QtWidgets.QWidget):
                checkbox.setChecked(value.isEnabled())
                checkbox.toggled.connect(
                    lambda checked=checkbox.isChecked(), v=value: v.setEnabled(checked)
                )
                widget_container.addWidget(value)
            self.main_layout.addRow(widget_container)

        self.main_layout.addRow(ok_close_layout)

    def create_connections(self):
        self.overscan_slider.valueChanged.connect(
            lambda: self.overscan_value.setText(
                str(self.get_float(self.overscan_slider.value()))
            )
        )

        self.gate_mask_opacity_slider.valueChanged.connect(
            lambda: self.gate_mask_opacity_value.setText(
                self.get_float(self.gate_mask_opacity_slider.value())
            )
        )

        self.gate_mask_color_picker.clicked.connect(
            lambda: self.show_color_selector(self.gate_mask_color_picker)
        )

        self.gate_mask_color_slider.valueChanged.connect(
            lambda: self.update_button_value(self.gate_mask_color_slider.value())
        )

        all_widgets = [
            self.near_clip_plane,
            self.far_clip_plane,
            self.overscan_value,
            self.gate_mask_opacity_value,
        ]

        for widget in all_widgets:
            widget.returnPressed.connect(self.apply_settings)

        self.ok_btn.clicked.connect(partial(self.apply_settings, close=True))
        self.close_btn.clicked.connect(lambda: self.close())

    def get_float(self, value):
        return "{:.3f}".format(value / 1000.0)

    def update_button_color(self):
        rgb = self.parentUI.default_gate_mask_color[0]
        qcolor = QtGui.QColor(*[int(q * 255) for q in rgb])
        h, s, v, _ = qcolor.getHsv()
        qcolor.setHsv(h, s, v)
        self.gate_mask_color_picker.setStyleSheet("background-color: " + qcolor.name())
        self.gate_mask_color_slider.setValue(v)

    def update_button_value(self, value):
        color = self.gate_mask_color_picker.palette().color(QtGui.QPalette.Button)
        h, s, v, _ = color.getHsv()
        color.setHsv(h, s, value)
        self.gate_mask_color_picker.setStyleSheet("background-color: " + color.name())

    def show_color_selector(self, button):
        initial_color = button.palette().color(QtGui.QPalette.Base)
        color = QtWidgets.QColorDialog.getColor(initial=initial_color)
        if color.isValid():
            button.setStyleSheet("background-color: " + color.name())
            h, s, v, _ = color.getHsv()
            self.gate_mask_color_slider.setValue(v)

    def apply_settings(self, close=False):
        near = float(self.near_clip_plane.text()), self.near_clip_plane.isEnabled()
        far = float(self.far_clip_plane.text()), self.far_clip_plane.isEnabled()
        overscan = float(self.overscan_value.text()), self.overscan_value.isEnabled()
        mask_op = (
            float(self.gate_mask_opacity_value.text()),
            self.gate_mask_opacity_value.isEnabled(),
        )
        r, g, b, _ = (
            self.gate_mask_color_picker.palette().color(QtGui.QPalette.Button).getRgb()
        )
        mask_color = [
            round(x / 255.0, 3) for x in [r, g, b]
        ], self.gate_mask_color_picker.isEnabled()

        self.parentUI.process_prefs(
            near=near,
            far=far,
            overscan=overscan,
            mask_op=mask_op,
            mask_color=mask_color,
        )
        if self.parentUI.default_cam[1]:
            self.parentUI.default_cam_btn.setText(self.parentUI.default_cam[0])
        if close:
            self.close()


"""
Coffee window
"""


class Coffee(QtWidgets.QMessageBox):
    def __init__(self, version):
        super(Coffee, self).__init__()

        base64Data = "/9j/4AAQSkZJRgABAQAAAQABAAD/4QAqRXhpZgAASUkqAAgAAAABADEBAgAHAAAAGgAAAAAAAABHb29nbGUAAP/bAIQAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFAEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBMUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAIAAgAwERAAIRAQMRAf/EABkAAQEAAwEAAAAAAAAAAAAAAAcIBAUGA//EACwQAAEEAQIFAwIHAAAAAAAAAAECAwQRBQYSAAcIEyEiMUFRYRQXMkJTcdH/xAAbAQACAgMBAAAAAAAAAAAAAAAHCAUJAwQGAf/EADMRAAEDAgQEBAQFBQAAAAAAAAECAxEEIQAFEjEGQVFhB3GBoRMikcEUUrHR8CMkMkKC/9oADAMBAAIRAxEAPwBMTk04Rt2a73iwwkrcTHZW84oD4S2gKUo/QJBPDD1rqWWFOKSVRyAk4r64fbdqcwbp23Ut6jErVpT6n9Le04DdRdXULV+YaY0jraJjWEqUFRcjGfipWgD004pKNzilV43gAK9lbfK15tnNdXVDigpSGv8AUJUAQOqikzfcjbl1JsX4e4To8pomkOIQt8f5qWglJJ5I1AC2wNp3IvGMmZ1Kaq0TiX52Oy6ZsxlAWuDkkLWknxdtqWSUfdpY+nnzxG0WaZhTODS8VJnZR1A+puPqOuJ+uynLX25LISoflGg/QWPnfFhcrtfsczeWmltXx2Uxm81Aalqjpc7gZcIpxvdQ3bVhSboXXsODDTO/iWg51wJ3CaZ5TKjsYwaYxtxWSjBlG93uJ2pPizfgcEWqWlFO4tatIAMnpbf0whWWoW9WsNtN/EUpaQEzGolQhM8pNp5Y9dTdL2L1viUymtOQYUl38S/PLUJp9yQvuLIKVFVW4ACNxFbxuAIIClIV/ckSCkmdRvHPy9t8WwLdIohqKkqQAAgEJmIHcjsJ2xInU9034flVAwLaMw+xLnyi21go0r1BPkdwIBpPkijQ/VXzxnYe1VBTII6xyx49TlVAXdBFhuZv0nmcUv0XtL0pyQh6bfeEl3HzH3DITVOd5Xe+PkFZH3q/mgV+HHBU0ytIjSY9gfvgDcSqNDXIC1SVpnyuR9sbPC5VnM4yHlIal9iQgOtlSSlQsX5HweCVQ11Nm1KHmTqQrcH3BH6/thJ87ybMuFM0XQVo0PNkEEGx5pWhVrHcGxBsYUCB0M/X3MBnDpwumdPOZtx5oNsZBqWywzEtSrMkuGwkWPWEuGgAGybJXfP8nZy3M3WdWls/MkdjuB5GfSMWD+HnFj3E3DtPWuJ+JUIJbcJkypAEExeVJgmI+YkzEAAXNblvhovPLQULNsxcjlZjiXJZYBbakPNRXHnFBPg7N7QofQgH54x8LUjdbmTbCh/TJMjsEkj3jEz4lZ/W5NwvUV7bhDqQkJ5wVOJTaexOGnBZJvBNNQ48duLDbG1DbIoJ/wB/v34ZFvLWKdkNU6dIHLCCN8W1tVVGor1lalbn+cuw2wfa61V+UuIm5ZEbv4kJLiGN5Cd/8RNHZZPpPmhYqkgEaOUdZw/nCXqITTvH5hyBuT5dUn/nYDBnymvyrxL4WOV50rTmNImG3N1qTYJPLV+VwE7wuQVWP+R/UxqfI6zU7LisZuLkEOJh41qmkR1NpWu0GlE2EkEqJ/b5HgcaXFtInMqP8cpUKb7bgkCPQ3+vUYKXh3TU/Cr5yqkSSl66iTfUATJ5XFoAGw3ucAevubuvub3PsaoabVpqZhlKjwURyHRGJ9Cxak04VBRCrFV4r3uG4cy59pSXW5TBmY35fS/rOOu4yqqDMmHMvqQHUKEFM23mZBnUCAbGxHnLjh+oHPY/JoGpsdClY9e1C3cSwtpxo3RXtW4sLH2FHwas0kmtuvUD84kdsKfmPh5S/BJy5xQcF4WQQe0pSnSe5kdYEkf/2Q=="
        if get_python_version() < 3:
            image_64_decode = base64.decodestring(base64Data)
        else:
            image_64_decode = base64.decodebytes(base64Data.encode("utf-8"))
        image = QtGui.QImage()
        image.loadFromData(image_64_decode, "JPG")
        pixmap = QtGui.QPixmap(image).scaledToHeight(
            DPI(56), QtCore.Qt.SmoothTransformation
        )
        self.setIconPixmap(pixmap)

        self.setWindowTitle("About")
        self.setText(
            '<p><font color="white">Cams - '
            + version
            + '</p>By @Aleha - <a href=https://www.instagram.com/alejandro_anim><font color="white">Instagram</a><br>My website - <a href=https://alehaaaa.github.io><font color="white">alehaaaa.github.io</a><br><br>If you liked this set of tools,<br>you can send me some love!'
        )
        self.setFixedSize(DPI(400), DPI(300))
