import maya.cmds as cmds, maya.mel as mel, os, json
from PySide2 import QtWidgets, QtCore, QtGui

from .settings import *
from .util import *


def get_camsDisplay_modeleditor():
    model_editor_cameras = {}
    panels = cmds.getPanel(type="modelPanel")
    for pl in panels:
        if cmds.modelEditor(pl, exists=True):
            cam = cmds.modelEditor(pl, q=True, camera=True)
            if cam:
                cam = cam.split("|")[-1]
                if cmds.objExists(cam + ".cams_display"):
                    model_editor_cameras[pl] = cam
    return model_editor_cameras


def get_preferences_display(cam):
    cam_attr = cam + ".cams_display"
    if cmds.objExists(cam_attr):
        attr_value = cmds.getAttr(cam_attr) or "{}"
        preferences = eval(attr_value)
    else:
        preferences = {}
        cmds.addAttr(cam, ln="cams_display", dt="string")
    return preferences


def get_cam_display(cam_panels, command, plugin=False):
    if plugin:
        var = eval(
            "cmds.modelEditor('"
            + cam_panels[-1]
            + "', q=1, queryPluginObjects='"
            + command
            + "')"
        )
    else:
        var = eval("cmds.modelEditor('" + cam_panels[-1] + "', q=1, " + command + "=1)")
    return var


def set_cam_display(cam_panels, command, plugin=False, switch=None):
    var = get_cam_display(cam_panels, command, plugin) if switch == None else not switch
    for i in cam_panels:
        e_cmd = (
            "pluginObjects=('{}', {})".format(command, not var)
            if plugin
            else "{}={}".format(command, not var)
        )
        try:
            eval("cmds.modelEditor('{}', e=1, {})".format(i, e_cmd))
        except:
            continue


def look_thru(cam, pane=None, ui=None):
    pane = pane or cmds.getPanel(wf=True)
    try:
        cmds.lookThru(pane, cam)
    except:
        if ui:
            ui.reload_cams_UI()
        return
    preferences = get_preferences_display(cam)
    if preferences:
        for command, plugin_switch in preferences.items():
            plugin, switch = (
                plugin_switch if type(plugin_switch) == tuple else (plugin_switch, 0)
            )
            set_cam_display([pane], command, plugin=plugin, switch=switch)


def get_model_from_pos(pos):
    widget = QtWidgets.QApplication.widgetAt(QtCore.QPoint(*pos))
    """Check if a given QWidget is a model editor in Maya."""
    if isinstance(widget, QtWidgets.QWidget):
        model_editor = widget.parent()
        if model_editor:
            return model_editor.objectName()
    return None


def drag_insert_camera(camera, parent, pos):
    widget_name = get_model_from_pos(pos)
    if widget_name and widget_name.startswith("modelPanel"):
        look_thru(camera, widget_name, parent)

    else:
        tear_window = tear_off_cam(camera)
        window_widget = omui.MQtUtil.findControl(tear_window)
        window = wrapInstance(int(window_widget), QtWidgets.QWidget)

        cursor_pos = QtGui.QCursor().pos()
        window.move(cursor_pos.x() - window.width() / 2, cursor_pos.y() - window.height() / 2)


def select_cam(cam, button=None):
    if button:
        button.select_btn.setVisible(False)
        button.deselect_btn.setVisible(True)

    cmds.select(cam, add=True)


def deselect_cam(cam, button=None):
    if button:
        button.deselect_btn.setVisible(False)
        button.select_btn.setVisible(True)

    cmds.select(cam, deselect=True)


def duplicate_cam(cam, ui):
    cmds.undoInfo(openChunk=True)
    dup_cam = cmds.duplicate(cam)
    dup_cam = dup_cam[0]
    if cmds.listRelatives(dup_cam, parent=True):
        cmds.parent(dup_cam, w=1)
    cmds.showHidden(dup_cam)
    cmds.setAttr(cmds.listRelatives(dup_cam, shapes=True)[0] + ".renderable", False)
    cmds.undoInfo(closeChunk=True)

    ui.parentUI.reload_cams_UI()
    try:
        ui.context_menu.close()
    except:
        pass


def check_if_valid_camera(cam):
    if cmds.camera(cam, q=1, startupCamera=True):
        return "Default camera '" + cam + "' cannot be renamed."
        
    elif cmds.referenceQuery(cam, isNodeReferenced=True):
        return "Referenced camera '" + cam + "' cannot be renamed."


def rename_cam(cam, ui):
    check = check_if_valid_camera(cam)
    if check:
        cmds.warning(check)
        return

    re_win = QtWidgets.QInputDialog()
    re_win.setWindowTitle("Rename " + cam)
    re_win.setLabelText("New name:")
    re_win.setTextValue(cam)

    re_win.setWindowFlags(re_win.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint)

    result = re_win.exec_()

    if result == QtWidgets.QDialog.Accepted:
        input = re_win.textValue()
        cmds.rename(cam, input)
        ui.reload_cams_UI()


def delete_cam(cam, ui):
    check = check_if_valid_camera(cam)
    if check:
        cmds.warning(check)
        return

    if cmds.objExists(cam):
        delete = QtWidgets.QMessageBox()
        response = delete.warning(
            None,
            "Delete " + cam,
            "Are you sure you want to delete " + cam + "?",
            delete.Yes | delete.No,
            delete.No,
        )

        if response == delete.Yes:
            if cmds.objExists(cam + ".cams_type"):
                try:
                    delete_target = cmds.listRelatives(cam, allParents=True)[0]
                except:
                    delete_target = cam

                if cmds.nodeType(delete_target) != "dagContainer":
                    try:
                        delete_target = cmds.listRelatives(
                            delete_target, allParents=True
                        )[0]
                    except:
                        pass
            else:
                delete_target = cam
            cmds.undoInfo(openChunk=True)
            cmds.delete(cam, inputConnectionsAndNodes=True)
            cmds.delete(delete_target, hierarchy="both")
            cmds.undoInfo(closeChunk=True)
    ui.reload_cams_UI()


def tear_off_cam(cam):
    tear_off_window = None
    for i in range(10):
        try:
            name = cam + "_WorkspaceControl" + (str(i) if i != 0 else "")
            tear_off_window = cmds.workspaceControl(name, label=cam, retain=False)
            break
        except:
            pass
    if tear_off_window == None:
        cmds.warning("Error making panel or too many Tear Off panels already made!")
        return

    cmds.paneLayout()
    new_pane = cmds.modelPanel()
    cmds.showWindow(tear_off_window)

    look_thru(cam, new_pane)
    cmds.modelEditor(new_pane, e=1, displayAppearance="smoothShaded")

    cmds.workspaceControl(tear_off_window, e=1, rsh=600, rsw=900)
    
    return tear_off_window


def close_UI(ui):
    if not ui:
        return
    currentShelf = cmds.tabLayout(mel.eval("$nul=$gShelfTopLevel"), q=1, st=1)
    tool = ui.TITLE.lower()

    def find():
        buttons = cmds.shelfLayout(currentShelf, q=True, ca=True)
        if buttons is None:
            return False
        else:
            for b in buttons:
                if (
                    cmds.shelfButton(b, exists=True)
                    and cmds.shelfButton(b, q=True, l=True) == tool
                ):
                    return True
        return False

    if not find():
        box = cmds.confirmDialog(
            title="About to close Cams!",
            message="Closing Cams will NOT reopen the UI on Maya's next launch.\nYou will have to use a Shelf button or run Cams launch script.\n\nAre you sure you want to continue?",
            button=["Yes", "Add to Shelf", "Cancel"],
            defaultButton="Cancel",
            cancelButton="Cancel",
            dismissString="Cancel",
        )

        if box == "Add to Shelf":
            cmds.shelfButton(
                parent=currentShelf,
                i=os.path.join(
                    os.environ["MAYA_APP_DIR"],
                    cmds.about(v=True),
                    "scripts",
                    "aleha_tools",
                    "_icons",
                    tool + ".svg",
                ),
                label=tool,
                c="import aleha_tools.{} as {};{}.UI().showWindow()".format(
                    tool, tool, tool
                ),
                annotation=tool.title() + " by Aleha",
            )
            ui.close()
        elif box == "Yes":
            ui.close()
    else:
        ui.close()


# Open Tools
def run_tools(tool, ui=None):
    if get_python_version() > 2:
        try:
            import importlib

            tool_module = importlib.import_module("aleha_tools._tools." + tool)
            importlib.reload(tool_module)
        except ImportError:
            cmds.error("Error importing module " + tool)
            return

        if ui:
            tool_instance = getattr(tool_module, tool)()
            tool_instance.show_dialog(ui)
        else:
            getattr(tool_module, tool)()

    else:
        cmds.warning("Work in Progress")


# Check for Updates
def check_for_updates(ui, warning=True):

    tool_folder = r"\\HKEY\temp\from_alejandro\cams_tool"

    if os.path.exists(tool_folder):
        versions_folder = os.path.join(tool_folder, "versions")
        latest_file = [v for v in os.listdir(versions_folder)][-1]
        latest_file_path = os.path.join(versions_folder, latest_file)

        _release_notes = os.path.join(tool_folder, "release_notes.json")
        if not os.path.exists(_release_notes) or not os.path.exists(latest_file_path):
            return
        else:
            with open(_release_notes, "r") as release:
                release_notes = json.load(release)
    else:
        if warning:
            make_inViewMessage(
                "<hl>No connection</hl>\nCould not sync with the server."
            )
        return

    try:
        changelog = release_notes.get("versions", "")
        version = next(iter(changelog))
    except:
        return

    notes_list = []
    for number, changes in changelog.items():
        version_changes = []
        version_changes.append(number)
        for line in changes:
            version_changes.append(" - " + line)
        notes_list.append(version_changes)

    notes_list = notes_list[:3]
    notes_list.append(["== And more =="])
    formated_changelog = "\n\n".join(["\n".join(x) for x in notes_list])

    if version > ui.VERSION:
        update_available = cmds.confirmDialog(
            title="New update for " + ui.TITLE + "!",
            message="Version {} available, you are using {}\n\nChangelog:\n{}".format(
                version, ui.VERSION, formated_changelog
            ),
            messageAlign="center",
            button=["Install", "Skip", "Close"],
            defaultButton="Install",
            cancelButton="Close",
        )
        if update_available == "Install":
            from . import updater

            try:
                from importlib import reload
            except:
                pass
            reload(updater)

            command = "import aleha_tools.cams as cams;cams.UI().showWindow()"
            # print(ui.TITLE.lower(), command, latest_file_path)
            updater.Updater().install(ui.TITLE.lower(), command, latest_file_path)
            cmds.evalDeferred(
                """
import aleha_tools."""
                + ui.TITLE.lower()
                + """ as cams
try:
    from importlib import reload
except ImportError:
    pass
reload(cams)
cams.UI().showWindow()
"""
            )
            make_inViewMessage(
                "Update finished successfully\ncurrent version is now <hl>"
                + version
                + "</hl></div>"
            )

        elif update_available == "Skip":
            ui.process_prefs(skip_update=True)

    elif warning:
        if version < ui.VERSION:
            make_inViewMessage(
                "You are using an unpublished\nversion <hl>'"
                + ui.VERSION
                + "'</hl></div>"
            )
        else:
            make_inViewMessage(
                "You have the latest\nversion <hl>'" + ui.VERSION + "'</hl></div>"
            )
