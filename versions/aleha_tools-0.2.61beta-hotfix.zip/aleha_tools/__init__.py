"""

TO-DO:
    - Make it fully Python 2 compatible

    IDEAS:
    - Add HeadsUpDisplay presets

    FUTURE:

"""

DATA = {
    "TOOL": "cams",
    "VERSION": "0.2.61beta-hotfix",
    "AUTHOR": {
        "name": "Alehaaa",
        "website": "https://alehaaaa.github.io",
        "instagram": "https://www.instagram.com/alejandro_anim/",
    },
}
