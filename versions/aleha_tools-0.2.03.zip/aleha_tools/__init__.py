"""

TO-DO:
    - Make it Python 2 compatible
    
    IDEAS:
    - Add Show Viewport presets?
    
    WIP:
    - Error handling for startup

    FUTURE:

"""


DATA = {
    'TOOL': "cams",
    'VERSION': '0.2.03',
    'AUTHOR': {
        'name': "Alehaaa",
        'website': "https://alehaaaa.github.io",
        'instagram': "https://www.instagram.com/alejandro_anim/",
    }
}






